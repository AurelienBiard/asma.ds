# Pattern Collection card

> **Status**: reclassified on 2026-11-19 from the components `Card-collection`, `Block-header` and `Card-item` (promoted from ASMA OS on 2026-11-07). The pattern is "a card that lists a group of related entries, capped at five, with a link to the full list". The three bricks stay Figma components. Figma page: `↳ Collection card` (section `💻 PATTERNS`, formerly `↳ Card-collection`). No token created.

## Purpose

Present a collection or group of related information on a detail page or a home screen: header, free list of rows (one per entity), optional footer.

## Use when

- Related collection or group of information on a detail page (contacts of a company, tasks of a project, information) and on home screens (today, agenda, notes, favourite resources).
- The list is short (5 items maximum).

## Do not use when

- A simple container with title / text / actions → `Card`.
- A long list or comparable columns → `Table` (pattern `DataTable`).
- Items moved between statuses → pattern `Kanban`.
- Nested inside another card: never.

## Components

- `Card-collection` (brick, ComponentSet) — the container.
- `Block-header` (brick, ComponentSet) — header: icon, title, count, filter, actions.
- `Card-item / Note | Tâche | Contact | Relation | Information | Projet` (bricks) — one row per entity.
- `Button` (`Neutral`, `Outlined`) in the footer; `Select`, `Count`, `Icon` in the header; `Tag`, `Checkbox`, `Avatar` inside rows.

## Structure

`Card-collection` → `Block-header` → free **Slot** receiving `Card-item` rows → optional `cardFooter`. The last `Card-item` has no divider (`Show-divider=false`).

## Interaction flow

1. Rows open the entity (link or wrapping button).
2. Beyond 5 items, the footer proposes "Tous les … (N)" leading to the full list.
3. Mobile: the header toggles collapse (`State=Collapsed`).

## States

`Expanded`, `Collapsed` (mobile), empty (proposed: `Empty-state` Compact in the slot), loading (`Skeleton` rows).

## Validation/errors

None (read-only list); actions of rows follow their component.

## Accessibility

See brick sections: region with `aria-labelledby`, `aria-expanded` on the mobile toggle, rows as list items.

## Responsive behavior

`Device` = `Desktop` (752), `Desktop-sidebar` (360), `Mobile` (393, collapsible).

## Tokens

See brick sections. No token created.

## Related components/patterns

`Card`, `List-group-header` (group header inside a list, not a section title), `Search-results` (reuses `Card-item` rows); patterns `Search`, `Kanban`.

---

## Brick: Card-collection

Card that presents a **collection or group of information**: a block header (`Block-header`), a free content area (**Slot**) receiving `Card-item` rows, and an optional footer. **Distinct from `Card`** (generic title / body / actions container, `components/card/`): `Card-collection` lists related items and collapses on mobile. Decision of 2026-11-07: separate component, `Card` is not modified.

ComponentSet, 4 variants:

| Device | State | Width | Notes |
|---|---|---|---|
| `Desktop` | `Expanded` | 752 | padding `Spacing/component-md`, gap `Spacing/component-sm`, no footer |
| `Desktop-sidebar` | `Expanded` | 360 | side column, with `cardFooter` |
| `Mobile` | `Expanded` | 393 | padding `Spacing/component-xs`, gap `Spacing/component-2xs`, with `cardFooter` |
| `Mobile` | `Collapsed` | 393 | header only (60 px), collapsed |

- Properties: `Show-footer` (Boolean, `true`), `content` (Slot).
- `cardFooter`: `Secondary-action` (`Button` `Neutral`) and `Action` (`Button` `Outlined`).
- Fill `Background/elevated`.
- Accessibility: region (`role="region"`, `aria-labelledby` on the `Block-header` title); mobile collapse is a button with `aria-expanded`; each `Card-item` is a list item, a clickable item is a wrapping link or button, never a `div`.

## Brick: Block-header

Header of a content block (a `Card-collection` or a detail-page section): pictogram, title, counter, filter and actions. Section-level equivalent of `PageHeader`. Added at promotion because `Card-collection` depends on it.

- ComponentSet, `Device` = `Desktop` | `Mobile`.
- Properties: `Title`, `Description` (Text); `Show-icon` (true), `Show-count` (true), `Show-filter` (true), `Show-action` (true), `Show-secondary-action` (true), `Show-toggle` (false), `Show-description` (true) — defaults are those of the original component.
- `Title`: `Heading/SM`, `Text/primary`. `Description`: `Body/SM`, `Text/tertiary`. Gap `Spacing/component-xs`. Instances: `Icon`, `Count`, `Select`, `Button` (`Neutral` and `Outlined`).

## Brick: Card-item (row template)

Six components, one per entity, named `Card-item / Note`, `/ Tâche`, `/ Contact`, `/ Relation`, `/ Information`, `/ Projet`. One row: `row` (horizontal, vertical padding `Spacing/component-sm`, gap `Spacing/component-sm`) then `divider` (`Border/subtle`).

| Template | Content | Properties |
|---|---|---|
| `Note` | title, linked entities, date, pin | `Primary`, `Secondary`, `Date`, `Show-secondary`, `Show-pin`, `Show-divider` |
| `Tâche` | `Checkbox` (task label), `Tag`, due date | `Échéance`, `Show-tag`, `Show-due`, `Show-divider` |
| `Contact` | `Avatar` (`Initials`, `Small`), name, role, email or phone | `Primary`, `Secondary`, `Meta`, `Show-leading`, `Show-secondary`, `Show-meta`, `Show-divider` |
| `Relation` | type, since, `Tag` | `Primary`, `Secondary`, `Show-tag`, `Show-divider` |
| `Information` | label, value — **no divider** | `Label`, `Value` |
| `Projet` | name, period, `Tag` | `Primary`, `Secondary`, `Show-tag`, `Show-divider` |

Tokens: `Primary` `Misc/Label` + `Text/primary`; `Secondary` and `Date` `Body/SM` (`Text/secondary`; `Text/tertiary` for a note date); `Information`: `Label` `Body/SM` + `Text/tertiary`, `Value` `Body/MD` + `Text/primary`, padding `Spacing/component-xs`, gap `Spacing/component-2xs`.

Rule: the last `Card-item` of a card has no divider (`Show-divider=false`). These templates are also the rows of `Search-results`.
