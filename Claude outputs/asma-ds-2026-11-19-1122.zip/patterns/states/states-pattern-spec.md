# Pattern States

> **Status**: spec only (2026-11-19). `Empty-state` exists as a component and `Skeleton` as a component; the loading and error treatments below are the **candidate** part (`ErrorState`, `LoadingState` previously listed as candidates). Choices marked "proposed" are to be validated.

## Purpose

Define what a view shows when it has no data, is loading, or failed — consistently across tables, lists, cards and pages.

## Use when

- Any container whose content can be empty, pending or in error.

## Do not use when

- Transient feedback → `Toast`.
- Known progress of an operation → `Progress`.
- Field-level errors → pattern `Form`.

## Components

- `Empty-state` (`Size=Compact` in cards, lists, table cells; `Size=Page` for pages, panels, drawers) — empty.
- `Skeleton` (`Shape` Text/Circle/Rectangle) — loading; composed to the exact shape of the final content.
- `Alert` / `Banner` (Inline or Page) — error, with a retry `Button`.

## Structure

Empty: icon (optional), title, description, one action. Loading: skeletons at the exact size of the content (no layout shift; shimmer in code). Error: message saying what failed and what to do, with a retry action; proposed to reuse `Banner` Inline inside the container.

## Interaction flow

1. Loading shows skeletons immediately (no spinner on top).
2. On success: content replaces skeletons; on empty result: `Empty-state`.
3. On failure: error message with retry; retry returns to loading.

## States

Loading, empty (first use: invite to create; filtered: "no result" with reset-filters action), error (retryable / not retryable).

## Validation/errors

Distinguish "empty because nothing exists" from "empty because of filters": the action differs.

## Accessibility

Loading containers use `aria-busy="true"`; skeletons are decorative; status changes (loaded, empty, error) announced in a polite live region; the retry action is focusable and named.

## Responsive behavior

`Compact` below the page level; `Page` for full-view states.

## Tokens

None specific (see `Empty-state`, `Skeleton`).

## Related components/patterns

`Empty-state`, `Skeleton`, `Alert`, `Banner`, `Button`; patterns `DataTable`, `Search`, `Kanban`, `FileUpload`.
