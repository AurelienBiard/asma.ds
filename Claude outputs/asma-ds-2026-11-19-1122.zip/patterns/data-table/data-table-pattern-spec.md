# Pattern DataTable

> **Status**: spec only (2026-11-19), no Figma page yet. Composition of existing components and patterns; no new component or token. Choices marked "proposed" are to be validated.

## Purpose

Browse a large tabular data set: search and filter it, select rows, act on the selection, move through pages, and handle the empty and loading cases consistently.

## Use when

- Comparable records shown in columns (companies, invoices, users).
- The set is too large to show at once (filters and pagination needed).

## Do not use when

- Editable cells and spreadsheet keyboard model → `DataGrid`.
- A short group of related entries inside a page → pattern `Collection card`.
- Items grouped by status → pattern `Kanban`.

## Components

- Pattern `FilterBar` — above the table (`patterns/filter-bar/`).
- `Table` (`Selectable=True` when rows can be acted on) — `components/table/`.
- `Pagination` — below the table.
- Pattern `BulkActions` — `Bulk-action-bar`, shown while rows are selected.
- `Empty-state` (`Size=Compact`, in the table area) and `Skeleton` rows — see pattern `States`.

## Structure

Vertical stack: filter bar → table → pagination, gap `Spacing/component-md` (proposed). The table container carries the outer border; the last row has no bottom border (rule of `Table`). The floating `Bulk-action-bar` does not push the layout; reserve bottom space while it is visible.

## Interaction flow

1. Typing or choosing a filter updates the table and resets to page 1 and clears the selection.
2. Selecting rows shows the `Bulk-action-bar`; "Select all" covers visible filtered rows only.
3. Changing page or sort clears the selection.
4. After a bulk action, the selection is cleared and a `Toast` reports the result.

## States

Loading (`Skeleton` rows with the same row height, no layout shift), populated, empty without filters (`Empty-state` with a create action), empty with filters (`Empty-state` "Aucun résultat" with a reset-filters action), error (`Banner` Inline with retry), rows selected.

## Validation/errors

A failed load keeps the previous filters and shows the error; a failed bulk action keeps the selection (see `BulkActions`).

## Accessibility

Native table semantics (`Table` spec); live region announcing the result count after filtering; selection checkboxes named per row; focus is not moved when the bulk bar appears. Pagination is a `nav` with `aria-label`.

## Responsive behavior

Desktop: full table. Mobile (< 768 px): proposed — horizontal scroll of the table with the first column sticky, `Pagination` compact; do not switch to cards without a spec.

## Tokens

None specific; inherited from the composed components.

## Related components/patterns

`Table`, `Pagination`, `Empty-state`, `Skeleton`; patterns `FilterBar`, `BulkActions`, `States`, `Confirmation`.
