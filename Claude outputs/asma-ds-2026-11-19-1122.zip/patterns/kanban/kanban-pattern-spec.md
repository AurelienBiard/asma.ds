# Pattern Kanban

> **Status**: reclassified on 2026-11-19 from the component `Kanban-card` (created 2026-11-16). A Kanban is a workflow (columns = statuses, cards move between them); the card is its brick. Figma page: `↳ Kanban` (section `💻 PATTERNS`, formerly `↳ Kanban-card`). The brick stays a Figma ComponentSet (`Kanban-card`) so that instances exist. Items marked "proposed" are to be validated.

## Purpose

Show items grouped by status or stage, one column per status, and let the user move an item from one column to the next. The pattern owns the arrangement (columns, ordering, movement), not only the card.

## Use when

- Items go through a small set of ordered statuses (to do / doing / done, pipeline stages).
- Moving an item between statuses is a frequent action.

## Do not use when

- Items have no status progression → `List` or `Table`.
- Many comparable attributes per item → `Table`.
- A group of related read-only entries inside a page → pattern `Collection card`.
- Rich content per item (image, several actions) → `Card`.

## Components

- `Kanban-card` (`Kanban-card`, brick, ComponentSet `State`) — one card per item. See "Brick: Kanban-card" below.
- `List-group-header` (`components/list-group-header/`) — proposed column header: status label + `Count`.
- `Menu` — the "⋯" menu of a card (Edit · Complete · Delete · Move to…).
- `Empty-state` (`Size=Compact`) — empty column. `Skeleton` — loading column.
- `Toast` — feedback after a move or a deletion (with Undo).

## Structure

Manual assembly (the number of columns and cards is arbitrary, same reasoning as `Table`): a horizontal row of columns; each column = header + vertical stack of `Kanban-card` (gap `Spacing/component-xs`). Column width is the card width (256 px). The row scrolls horizontally when columns overflow. Order inside a column is defined by the product (for example due date).

## Interaction flow

1. The card opens the item detail (click / Enter).
2. Drag and drop moves the card to another column; the card is in `State=Dragging` and its original slot is shown (dashed frame, code only).
3. Keyboard alternative (mandatory): the card menu offers "Move to…" with the list of columns.
4. After the move, the column change is announced (`aria-live`) and a `Toast` with Undo confirms it.

## States

Per card: `Default`, `Hover`, `Focus`, `Dragging`, `Done` (see brick). Per column: populated, empty (`Empty-state` Compact), loading (`Skeleton`), drop target highlighted while dragging (proposed: `Border/focus`).

## Validation/errors

A move that the product refuses (forbidden transition, permissions) returns the card to its origin column and shows an error `Toast`. A failed move never leaves the card in an intermediate state.

## Accessibility

See the brick section for the card. Columns: `role="list"` with an accessible name = status label + count; each card is a list item. Drag and drop always has the keyboard alternative above.

## Responsive behavior

Desktop: columns side by side, horizontal scroll. Mobile (< 768 px): one column at a time (proposed: `Tabs` or `SegmentedControl` to switch status), drag and drop replaced by "Move to…".

## Tokens

Those of the brick; column gap `Spacing/component-sm` (proposed). No new token.

## Related components/patterns

`Kanban-card`, `List-group-header`, `Count`, `Menu`, `Empty-state`, `Toast`; patterns `Collection card`, `DataTable`, `BulkActions`.

---

## Brick: Kanban-card

Figma ComponentSet `Kanban-card`, 5 variants (`State`). Card of one item in a Kanban column: title, context, secondary information, importance marker. **Generic**: the item can be a task, a ticket, an application, a request.

**Reuse example**: `OS / Task-card` (ASMA OS, Tasks Kanban) is a task card built on this model — the local component keeps its vocabulary (task, due date, priority *High*); `Kanban-card` carries the reusable structure and rules.

### Variants

- **`State`**: `Default` · `Hover` · `Focus` · `Dragging` · `Done`.
  - `Default`: 1 px `Border/default`.
  - `Hover`: `Border/strong` + `Elevation/2`.
  - `Focus`: 2 px `Border/focus`.
  - `Dragging`: lifted card, `Elevation/2`. **Code only**: −2° rotation and the origin slot shown as a dashed frame (not reproduced in Figma).
  - `Done`: title struck through in `Text/secondary` (completed item). **The strikethrough exists only on this variant.** Figma limit: if the `Title` of `Done` stays bound to the text property, the strikethrough propagates to all variants; this `Title` is therefore **not bound** to the `Title` property — in a `State=Done` instance, edit the text directly on the layer.
- No `Interactive` axis: a Kanban card is always clickable (opens the detail) and draggable.

Fixed width **256 px** (the column fills it), height follows content (a long title wraps).

### Anatomy

`Kanban-card` (vertical, fill `Background/elevated`) → `Title` · `Context` · `meta` (`Meta` + `flag`).

### Properties

| Property | Type | Default | Role |
|---|---|---|---|
| `State` | Variant | `Default` | Visual state |
| `Title` | Text | "Revoir la maquette du tableau de bord" | Item label |
| `Context` | Text | "Projet Alpha · Équipe Design" | Attachment (project · client · contact…) |
| `Meta` | Text | "29 oct." | Secondary information: due date, date, counter |
| `Flag-label` | Text | "Haute" | Importance marker label |
| `Show-context` | Boolean | `true` | Shows `Context` |
| `Show-meta` | Boolean | `true` | Shows `Meta` |
| `Show-flag` | Boolean | `true` | Shows the marker (`Flag` icon + `Flag-label`) |

If `Show-meta` and `Show-flag` are both `false`, the `meta` row is empty but keeps its spacing: also hide the row in code.

### Tokens

- Fill `Background/elevated` · border `Border/default` (`Border/strong` Hover, `Border/focus` Focus) · `Radius/card` · padding `Spacing/component-sm` · gap `Spacing/component-xs` · shadow `Elevation/2` (Hover, Dragging).
- `Title`: Text Style `Misc/Label`, `Text/primary` (`Text/secondary` + strikethrough in `Done`) · `Context`, `Meta`: `Body/SM`, `Text/secondary` · `Flag`: icon + label `Body/SM` in `Feedback/Danger`.
- `Meta` is neutral by default; to flag lateness, switch it to `Feedback/Danger/text` (ASMA OS usage).

### Usage

- Inside a Kanban column. Not nested in a `Card`.
- No inline action: "⋯" menu (Edit · Complete · Delete) and drag and drop. The marker is shown only for the highest level.

### Accessibility

- The card is a wrapping link or button (opens the detail); accessible name = `Title` + `Context`.
- Drag and drop: **mandatory keyboard alternative** ("Move to…" in the card menu); the column change is announced (`aria-live`).
- The marker does not rely on color alone (icon + label); a `Done` item is not signalled by the strikethrough alone: the column carries the status.
