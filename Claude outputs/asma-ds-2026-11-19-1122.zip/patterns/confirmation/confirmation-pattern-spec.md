# Pattern Confirmation

> **Status**: spec only (2026-11-19), no Figma page yet. Formalises the confirmation already required by `BulkActions` and by `Dialog-toolbar`. No new component. Choices marked "proposed" are to be validated.

## Purpose

Make the user confirm a destructive or irreversible action once, with the exact consequence stated, then give feedback.

## Use when

- Permanent deletion, loss of data, an action that affects others.
- A batch action (one confirmation for the whole batch).

## Do not use when

- A reversible action: run it and offer Undo in a `Toast` instead; do not ask first.
- Non-destructive information → `Banner` or `Toast`.

## Components

- `Dialog` (`Dialog-header`, `Dialog-body`, `Dialog-footer`) — the confirmation.
- `Button` — `Destructive` (Button type; see `components/button/`) for the confirming action, `Ghost`/`Outlined` for Cancel.
- `Toast` — result, with Undo/Restore when possible.

## Structure

Header: question naming the object and count ("Supprimer 5 entreprises ?"). Body: consequences in one or two sentences. Footer: Cancel (left of the confirming action) and the destructive action labelled with the verb, never "OK".

## Interaction flow

1. The user triggers the action; the `Dialog` opens; focus goes to Cancel (the safe action).
2. Confirm runs the action once; Esc or Cancel closes without effect.
3. A single `Toast` reports the outcome for the whole batch, with Undo/Restore if the action is reversible server-side.

## States

Open, confirming (action in progress, buttons disabled), success, error (error `Toast`, nothing changed).

## Validation/errors

For very high-impact deletions, require typing the object name (proposed, only where the product needs it).

## Accessibility

`role="alertdialog"` with the title and consequences as name and description; focus trapped and returned to the trigger on close; the action button names the verb and object.

## Responsive behavior

`Dialog` on desktop; on mobile the same content in a bottom-anchored container (proposed).

## Tokens

None specific.

## Related components/patterns

`Dialog`, `Button`, `Toast`; patterns `BulkActions`, `Form`, `DataTable`.
