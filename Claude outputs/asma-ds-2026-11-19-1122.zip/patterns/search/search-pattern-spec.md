# Pattern Search

> **Status**: reclassified on 2026-11-19 from the component `Search-results` (promoted from ASMA OS on 2026-11-07). The pattern is "search field + grouped results panel"; `Search-results` is the panel brick (Figma component kept). Figma page: `↳ Search` (section `💻 PATTERNS`, formerly `↳ Search-results`). Items marked "proposed" are to be validated.

## Purpose

Let the user type a query in a `Search` field and get a preview of the best results grouped by family, with a link to the full results. The pattern owns the whole workflow: field, panel, keyboard navigation, states.

## Use when

- Global or section search where results span several families (projects, notes, tasks, contacts).
- A quick preview is enough, with a "see all results" link.

## Do not use when

- Commands and navigation by keyboard (modal palette, `Ctrl/Cmd + K`) → `Command`.
- Choosing a value in a form → `Select`.
- Filtering a data set already on screen → pattern `Filter bar`.
- Mobile: do not use the panel; use a dedicated search screen (recents, then results).

## Components

- `Search` (`components/search-input/`) — the anchor field.
- `Search-results` (brick, Figma component) — the panel. See "Brick: Search-results".
- `List-group-header` (`components/list-group-header/`) — one per family: label + result count.
- `Card-item` rows (`patterns/collection-card/`) — one row per result.
- `Empty-state` (`Size=Compact`) — no result. `Skeleton` — loading.

## Structure

Field `Search`, then the panel anchored under it (width 480 px). Groups are assembled by hand: the number of families is arbitrary (same reasoning as `Table`).

## Interaction flow

1. Focus on the empty field: recents (state to provide).
2. Typing: results appear grouped, up to five rows per group; a family without result is not shown.
3. Arrow up/down moves in the list, Enter opens the result, Esc closes the panel and returns focus to the field.
4. Footer link "Voir tous les résultats pour « … »" opens the full results page.

## States

Recents (empty field), loading (`Skeleton`), results, no result (`Empty-state` Compact), error (proposed: inline `Alert` in the panel with retry).

## Validation/errors

No validation. A failed query shows the error state and keeps the typed text. The result count is announced.

## Accessibility

See the brick section (combobox pattern, `aria-live`).

## Responsive behavior

Desktop: anchored panel. Mobile: dedicated search screen, no panel.

## Tokens

Those of the brick. No new token.

## Related components/patterns

`Search`, `Search-results`, `List-group-header`, `Card-item`, `Command`, `Empty-state`, `Skeleton`; patterns `Filter bar`, `Collection card`.

---

## Brick: Search-results

Figma page `↳ Search` (single component). Dropdown panel of **grouped results**, anchored to a `Search` field: a preview of the best results per family, then a "See all results" link. Close to a `Combobox` and to `Command`, but without its own input: it is the list attached to the `Search` field.

### Search-results, Command, Select

| Component | Role |
|---|---|
| `Command` | Modal palette (`Ctrl/Cmd + K`) of commands and navigation. |
| `Search-results` | Preview of the results of a `Search` field, anchored under it, secondary. |
| `Select` | Choosing a value in a form (unrelated). |

### Anatomy

- **Groups**: `List-group-header` (family + result count) followed by its `Card-item` rows (`Projet`, `Note`, `Tâche`, `Contact`…), separated by `Border/subtle`, no separator on the last row of a group. Five rows maximum per group; a family without result does not appear.
- **Footer** (`searchFooter`): `Footer-label` (link "Voir tous les résultats pour « … »", `Text/link`) and `Footer-hint` (shortcut, `Text/tertiary`), hidden via `Show-footer`. Fill `Background/subtle`.

The example shows Projects, Notes and Tasks.

### Properties

`Show-footer` (Boolean, `true`), `Footer-label` (Text), `Footer-hint` (Text).

### Tokens

Width 480 px · fill `Background/elevated` · border `Border/subtle` (1 px) · shadow `Elevation/2` (Effect Style) · footer `Background/subtle`. No token created.

### Accessibility

- Combobox pattern: the `Search` field has `role="combobox"` with `aria-expanded` and `aria-controls` pointing to the list (`role="listbox"`); each row `role="option"`, each group `role="group"` with `aria-labelledby`.
- Arrow up/down to navigate, Enter to open, Esc to close and return focus to the field.
- Result count announced in an `aria-live="polite"` region.
