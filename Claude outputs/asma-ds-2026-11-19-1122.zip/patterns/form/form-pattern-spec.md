# Pattern Form

> **Status**: spec only (2026-11-19), no Figma page yet. Generalises the composition shown in `patterns/authentication/login-pattern-spec.md` to any labelled form. No new component. Choices marked "proposed" are to be validated.

## Purpose

Collect structured input: labelled fields, validation, feedback, a submit action. Defines how fields are stacked, how errors appear and where the actions go.

## Use when

- Creating or editing a record, settings, sign-up, any multi-field entry.

## Do not use when

- A single field → the input component directly.
- Sign in → pattern `Login` (a specialised form).
- File upload only → pattern `FileUpload`.
- Query with many criteria → `QueryBuilder` (candidate).

## Components

- `Field` (default choice for a labelled input; `Label` only when the fixed layout of `Field` does not fit — see `components/label/`) with `TextInput`, `Textarea`, `Select`, `Checkbox`, `Radio`, `Switch`, `DateTimePicker`, etc. swapped into it.
- `Banner` (Inline) or `Alert` — form-level error or information.
- `Button` — `Primary` to submit, `Ghost`/`Outlined` to cancel.
- In a `Dialog` or `Drawer`: `Dialog-header`, `Dialog-body`, `Dialog-footer`.

## Structure

Vertical stack of `Field` (spacing between fields: proposed `Spacing/component-md`), actions at the end. In a `Dialog`/`Drawer`, fields live in the body and actions (Cancel / Create) in the footer. **No `Dialog-toolbar` in creation forms**: there is nothing yet to complete or delete (see `Drawer` spec); the toolbar is for an existing item only.

## Interaction flow

1. The user fills fields; validation runs on blur for a field and on submit for the whole form (proposed).
2. On submit with errors: fields show their error state, focus moves to the first invalid field, and a form-level `Banner` summarises if there are several.
3. On success: close the container or navigate, and confirm with a `Toast`.
4. Closing with unsaved changes asks for confirmation (pattern `Confirmation`).

## States

Pristine, editing, field error, form error, submitting (primary `Button` loading, fields disabled), success, disabled.

## Validation/errors

Error text under the field, in words, saying how to fix it; required fields are marked in the label; never rely on color alone. Server errors that are not tied to a field go to the `Banner`.

## Accessibility

Each input has a programmatic label; errors linked with `aria-describedby` and `aria-invalid`; the first error receives focus on submit; form-level errors in a live region. The focus ring of inputs is drawn outside the field: never clip the containers holding inputs (`clipsContent` false).

## Responsive behavior

Single column at all sizes; actions full width on mobile (proposed).

## Tokens

None specific; inherited from the composed components.

## Related components/patterns

`Field`, `Label`, `TextInput`, `Select`, `Banner`, `Alert`, `Dialog`, `Drawer`; patterns `Login`, `FileUpload`, `Confirmation`.
