# ASMA Patterns

A pattern is a recurring workflow or interaction model composed of multiple
components. It is not a one-off screen composition.

## Where to find a pattern (single source of truth)

**The pattern list lives in `guidelines/decisions.yaml` → `pattern_selection`.** Each entry has the need in one sentence, English intent synonyms, the components used, the spec path, a status and a `not_for` pointer. This README only describes the spec format and where things are; it does not duplicate the list.

Lookup order for an agent: **need → pattern (`pattern_selection`) → component (`component_selection`) → token.**

Status values: `built` (Figma page + spec) · `spec` (spec only, no Figma page yet) · `candidate` (need recognised, no spec).

## Layout

- One folder per pattern: `patterns/<name>/<name>-pattern-spec.md` (Login: `patterns/authentication/login-pattern-spec.md`; Topbar and Site-nav are documented in `patterns/navigation/sidebar-pattern-spec.md`).
- Figma: one page per built pattern under the top-level `💻 PATTERNS` section.
- Bricks: a component that exists only to serve a pattern (for example `Kanban-card`) stays a Figma component, but its spec section lives inside the pattern spec and its `component_selection` entry redirects to the pattern.

## When is something a pattern and not a component

It is a pattern if at least two of these hold: it is mostly instances of other ASMA components; its value is a workflow or arrangement; it is assembled by hand with an arbitrary number of parts. It stays a component if it has its own atomic anatomy reused as a brick, or a single responsibility.

## Spec format

Purpose, Use when, Do not use when, Components, Structure, Interaction flow, States, Validation/errors, Accessibility, Responsive behavior, Tokens, Related components/patterns. Specs for patterns are written in English.

## Checking

`python3 scripts/check_patterns.py` verifies that spec folders and `pattern_selection` entries match, that paths exist, that required sections are present, and that bricks referenced in `component_selection` point to a real pattern.
