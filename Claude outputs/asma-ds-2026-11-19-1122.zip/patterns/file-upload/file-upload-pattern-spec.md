# Pattern FileUpload

> **Status**: spec only (2026-11-19), no Figma page yet. Arrangement of existing components; no new component. Open question: `Image-upload` is documented together with `Dropzone` and `Color Picker` in `components/dropzone/` (shared page `↳ File & media`); it may move here as a brick. Choices marked "proposed" are to be validated.

## Purpose

Let the user add one or several files by drag and drop or browsing, see progress, and handle rejected or failed files.

## Use when

- Importing documents or images into a form or a page.

## Do not use when

- Choosing among existing files → `Select` or `Command`.
- A profile picture only → `Avatar` with `Image-upload` (single square image, 96×96).

## Components

- `Dropzone` (`State` Default/Hover/Dragging/Error/Disabled) — multi-file area.
- `Image-upload` (`State` Empty/Filled/Hover/Disabled) — single square image.
- `Progress` — per-file progress.
- `Alert` or inline error text — rejected files; `Button` — remove or retry.

## Structure

`Dropzone` followed by a vertical list of uploaded files (name, size, `Progress`, remove action) (proposed row layout).

## Interaction flow

1. Drop files on the zone (`Dragging` state) or activate it to open the file picker.
2. Each file is checked (type, size) before upload; rejected files are listed with the reason.
3. Accepted files upload with a determinate `Progress`; a file can be removed or retried.
4. When the upload ends, the list shows the result; a `Toast` is optional.

## States

Dropzone: Default, Hover, Dragging, Error, Disabled. File row: queued, uploading (`Progress`), done, failed (retry), rejected.

## Validation/errors

Constraints (types, max size, max count) are stated in the zone before the user acts. A rejection says which rule failed and does not block the other files.

## Accessibility

The zone is a real button/file input reachable by keyboard (drag and drop is never the only way); progress exposed with `role="progressbar"` or equivalent text; added, removed and failed files announced in a live region.

## Responsive behavior

On touch devices the zone is a tap target opening the picker; the "drop here" wording is replaced by a neutral one (proposed).

## Tokens

None specific (see `Dropzone`).

## Related components/patterns

`Dropzone`, `Image-upload`, `Progress`, `Alert`, `Button`; patterns `Form`, `States`.
