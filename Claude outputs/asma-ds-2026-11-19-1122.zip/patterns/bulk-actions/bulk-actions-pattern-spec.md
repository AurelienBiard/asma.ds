# Pattern BulkActions

> **Status**: reclassified on 2026-11-19 from the component `Bulk-action-bar` (created 2026-11-09). The pattern is "select several items, act on all of them"; `Bulk-action-bar` is its floating bar (Figma ComponentSet kept). Figma page: `↳ Bulk-actions` (section `💻 PATTERNS`, formerly `↳ Bulk-action-bar`). No token created.

## Purpose

Act on several items of one collection at once (delete, restore, archive, tag, change status, postpone). The pattern covers selection, the floating bar, mixed selections, confirmation and feedback.

## Use when

- The collection allows selection (`Table` with `Selectable=True`, or a list with a selection mode).
- The same action applies to many items: delete, restore, archive, add a tag, change a status, postpone a due date.

## Do not use when

- An action on a single item → row actions, context menu or page actions.
- Filters, search, sort, view toggle (`SegmentedControl`), display settings (`Switch` "Show archived items") → pattern `Filter bar`, always reachable without a selection. The bar carries **only** actions on the selection.
- Actions of a form or panel → footer of `Dialog` / `Drawer`, `Dialog-toolbar`.

## Components

- `Table` (`Selectable=True`) or a selectable list — the collection; checkbox names: "Select row {name}", "Select all" with `aria-checked="mixed"`.
- `Bulk-action-bar` (brick, ComponentSet `Device=Desktop | Mobile`) — see "Brick: Bulk-action-bar".
- `Button` (`Ghost`, `Outlined`, `Destructive-ghost`), `Menu` (the `More` actions), `Tooltip` (disabled reason).
- `Dialog` — one confirmation for a destructive action. `Toast` — one result per batch.

## Structure

The bar is floating, bottom-centered over the content area, and appears when at least one item is selected. It does not push the content; the page reserves bottom space equal to its height while it is visible.

## Interaction flow

1. The user checks a row; the bar appears with a live count.
2. Optional "Select all ({n})": takes the **visible rows with current filters** only. Changing a filter, search, sort or page clears the selection.
3. The user triggers an action: up to three visible actions on desktop, then `More`; mobile: one action, then `More`; `Delete` is always last.
4. Destructive action: one `Dialog` stating the count and consequences ("Supprimer 5 entreprises ?"), then one `Toast` for the whole batch with *Undo* / *Restore*.
5. The bar disappears when the selection reaches 0 and after an action runs (selection cleared). The result `Toast` takes its place; a toast visible during a selection stacks above the bar.

## States

Hidden (0 selected), visible (≥ 1), action disabled (`State=Disabled`, reason in `Tooltip`), executing, success (`Toast`), error (error `Toast`, selection kept).

## Validation/errors

- **Mixed selection**: an action that concerns only part of the selection (for example "Archive" with already archived items) runs on the concerned items and says so in the toast ("3 sur 5 archivés"); if it concerns none, it is disabled with the reason in a `Tooltip`.
- **All or nothing**: a bulk action succeeds for the whole batch or fails without changing anything; on failure, error `Toast` and the selection is kept.

## Accessibility

See the brick section (`role="toolbar"`, live count, focus not moved).

## Responsive behavior

Desktop: hug width, centered on the content area (excluding the sidebar), `Spacing/section-xs` from the window bottom. Mobile: 361 px (16 px margins), 16 px from the bottom + `safe-area-inset-bottom`, above any back bar.

## Tokens

See the brick section. No token created.

## Related components/patterns

`Table`, `Button`, `Menu`, `Dialog`, `Toast`, `Tooltip`; patterns `Filter bar`, `DataTable`, `Confirmation`.

---

## Brick: Bulk-action-bar

Figma ComponentSet `Device=Desktop | Mobile`. Bulk action bar: it appears when **at least one item of a collection is selected** and carries the number of selected items and the actions that apply to the **whole selection**.

### Figma component properties

- **Device** (variant): `Desktop` / `Mobile`.
- **Selection-label** (Text, default "3 sélectionnés"): "1 sélectionné", "3 sélectionnés"; feminine if the product chooses so ("3 sélectionnées").
- **Show-select-all** (Boolean, default `true`): "Tout sélectionner ({n})" and the divider — desktop only, when the selection does not cover all visible rows.
- **Show-action-2**, **Show-action-3** (Boolean, default `true` / `false`) — desktop; on mobile these actions go into `More`.
- **Show-more** (Boolean, default `true`): `More` button, opens a `Menu` with the remaining actions.
- **Show-delete** (Boolean, default `true`): destructive action, always last.
- Exposed instances: `Action-1`, `Action-2`, `Action-3`, `More`, `Delete`, `Select-all` (label and icon editable from the bar instance).

### Anatomy

Horizontal row, centered, padding and gap `Spacing/component-xs`, height 60 (button 44 + 2 × 8).

1. **Clear** — `Button` `Ghost`, icon `X`, no label, 44×44; accessible name "Désélectionner tout".
2. **Selection-label** — text `Misc/Label`, `Text/primary`; mobile: `FILL`, one line, ellipsis.
3. **Select-all** — `Button` `Ghost` "Tout sélectionner ({n})" (desktop).
4. **Divider** — 1 × 24 rectangle, `Border/subtle` (desktop, with `Select-all`).
5. **Action-1 … Action-3** — `Button` `Outlined`, icon + label (desktop); mobile: `Action-1` only, icon only 44×44.
6. **More** — `Button` `Outlined`, icon `DotsThree`, no label 44×44.
7. **Delete** — `Button` `Destructive-ghost`, icon `Trash` + "Supprimer" (desktop), icon only (mobile).

| Element | Token |
|---|---|
| Fill | `Background/elevated` |
| Border | `Border/subtle`, 1 px |
| Radius | `Radius/card` |
| Elevation | `Elevation/3` (floating bar, like a sticky navigation — `foundations.yaml` → `elevation`) |
| Padding, gap | `Spacing/component-xs` |
| Label | `Misc/Label`, `Text/primary` |

### Position and motion

- Desktop: floating, hug width, no layout shift on appearance. Mobile: see pattern.
- Appearance: 8 px slide up + fade, `Motion/Duration/sm`, `Motion/Easing/standard`; `prefers-reduced-motion`: fade only.
- **Clear** and **Esc** (focus in the collection or the bar) clear the selection.

### Accessibility

- `role="toolbar"`, `aria-label="Actions sur la sélection"`; ← → navigation between buttons (roving tabindex), `Tab` leaves the bar.
- `Selection-label` in `aria-live="polite"` (announces "3 sélectionnés" on every change).
- The bar appearing **does not move focus** (it stays on the checked box); in the DOM the bar follows the collection.
- Buttons without label: `aria-label` ("Désélectionner tout", "Plus d'actions", "Supprimer la sélection", action label).

### Code (reference)

```html
<div class="bulk-bar" role="toolbar" aria-label="Actions sur la sélection">
  <button class="btn btn--ghost btn--icon-only" aria-label="Désélectionner tout">…X…</button>
  <span class="bulk-bar__label" aria-live="polite">3 sélectionnés</span>
  <button class="btn btn--ghost">Tout sélectionner (12)</button>
  <span class="bulk-bar__divider" aria-hidden="true"></span>
  <button class="btn btn--outlined">…Archive… Archiver</button>
  <button class="btn btn--outlined btn--icon-only" aria-label="Plus d'actions" aria-haspopup="menu">…DotsThree…</button>
  <button class="btn btn--destructive-ghost">…Trash… Supprimer</button>
</div>
```

```css
.bulk-bar {
  position: fixed; left: 50%; bottom: var(--spacing-section-xs); transform: translateX(-50%);
  display: flex; align-items: center; gap: var(--spacing-component-xs); padding: var(--spacing-component-xs);
  background: var(--color-background-elevated); border: var(--border-scale-thin) solid var(--color-border-subtle);
  border-radius: var(--radius-card); box-shadow: 0 20px 50px 0 var(--color-shadow-subtle); /* Elevation/3 */
}
.bulk-bar__label { font-size: var(--font-size-label); font-weight: var(--font-weight-scale-semibold); color: var(--color-text-primary); }
.bulk-bar__divider { width: 1px; height: 24px; background: var(--color-border-subtle); }
```
