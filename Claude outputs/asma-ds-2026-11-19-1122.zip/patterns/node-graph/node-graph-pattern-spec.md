# Pattern Node-graph

> **Status**: spec only (2026-11-19), no Figma page yet (an example graph page is planned). Arrangement of the existing `Node` family on `Canvas-dotted`. Behaviour references (React Flow, n8n) are inspiration, not rules. Choices marked "proposed" are to be validated.

## Purpose

Display and edit a graph of connected steps (workflow, pipeline, agent graph) on a free canvas: place nodes, connect ports, inspect and delete.

## Use when

- Steps with labelled inputs and outputs connected by links.
- A free spatial layout, with zoom and pan.

## Do not use when

- A linear journey to complete → `Step-indicator`.
- Hierarchical or tabular data → `Table`.
- Drawing arbitrary diagrams (not covered).

## Components

- `Canvas-dotted` — the surface (`components/canvas-dotted/`).
- `Node` (card), `Port` (labelled row), `Handle` (connection dot), `Edge` (link) — `components/node/`.
- `Menu` (node actions), `Tooltip`, `Toast` (feedback), `Empty-state` (empty canvas).

## Structure

`Canvas-dotted` fills the editing area; nodes are placed freely on it; edges are drawn between handles. Counts are arbitrary, so the graph is assembled by hand (like `Table`); the family documents the bricks, this pattern the arrangement. An example graph is the reference composition.

## Interaction flow

1. Drag from an output `Handle` to an input `Handle` to create an `Edge`; compatible targets show `Handle` `Hover`, incompatible ones `Invalid`.
2. Drag a node to move it; select to show its actions.
3. Keyboard alternative (mandatory): select a node, open "Connect to…" from its menu, choose the target port; arrow keys move a selected node (proposed step: 8 px).
4. Deleting a node deletes its edges; offer Undo in a `Toast`.

## States

Node: see `Node` states (default, selected, error…). Handle: `Default`, `Hover`, `Connected`, `Invalid`, `Disabled`. Canvas: empty (`Empty-state`), populated.

## Validation/errors

A refused connection (type mismatch, cycle) shows `Handle` `Invalid` during the drag and a `Tooltip` with the reason; nothing is created.

## Accessibility

The graph must be operable without pointer: nodes are focusable, ports are listed in the node's accessible description, connections are reachable through the keyboard flow above, and the list of connections is exposed as text (proposed: "Connections" panel). The dotted background is decorative (see `Canvas-dotted`).

## Responsive behavior

Desktop-first. On mobile, view-only with pan/zoom (proposed); editing is not supported.

## Tokens

None specific (see `Node` and `Canvas-dotted`).

## Related components/patterns

`Node`, `Port`, `Handle`, `Edge`, `Canvas-dotted`, `Menu`, `Tooltip`, `Toast`; patterns `Confirmation`, `States`.
