# Changelog

## 2026-11-09 (3) — Bulk-action-bar (barre d'actions groupées)

- Nouveau composant `Bulk-action-bar` (page `↳ Bulk-action-bar`, ComponentSet `Device=Desktop | Mobile`) : barre flottante en bas de la zone de contenu, visible dès qu'un élément d'une collection est sélectionné. Clear (X) · libellé « 3 sélectionnés » · « Tout sélectionner (n) » · séparateur · jusqu'à 3 actions `Outlined` · `More` (Menu) · `Delete` (`Destructive-ghost`). Mobile : Clear, libellé, une action, More, Delete. `Background/elevated`, `Border/subtle`, `Radius/card`, `Elevation/3`, padding et gap `Spacing/component-xs`.
- Propriétés : `Selection-label`, `Show-select-all`, `Show-action-2`, `Show-action-3`, `Show-more`, `Show-delete` ; instances exposées `Action-1..3`, `More`, `Delete`, `Select-all`.
- Règles : uniquement des actions sur la sélection (jamais filtres, tri, vue ou réglage d'affichage) ; « Tout sélectionner » = lignes visibles filtrées ; changer un filtre vide la sélection ; sélection mixte « 3 sur 5 archivés » ; une confirmation et un Toast par lot (Annuler / Restaurer) ; tout ou rien.
- Repo : spec `components/bulk-action-bar/`, renvoi dans la spec `table` (Sélection), `decisions.yaml`, `accessibility.yaml` (`selection`), `README.md`. Aucun token créé.

## 2026-11-09 (2) — Textarea : même Text Style que TextInput

- Figma : `Textarea` passe de `Body/SM` (12/16 Regular) à `Misc/Label` (14/20 Semi Bold), placeholder et texte saisi, sur les 32 variantes. Hauteur fixe de 160 px inchangée, troncature toujours désactivée.
- Spec `textarea` et guideline de la page `↳ Text inputs` corrigées.

## 2026-11-09 — Règle de couleur du texte des champs

- Règle formalisée pour `TextInput`, `PasswordInput`, `Search`, `Textarea`, `Select`, `TagInput` : placeholder (champ vide) `Text/tertiary`, texte saisi `Text/primary`, `Text/disabled` en Disabled ; la validation ne change pas la couleur du texte. Contrastes sur `Background/elevated` : tertiary 7,58:1 (Light) / 5,71:1 (Dark).
- Figma : déjà conforme sur tous les composants, aucune variante modifiée ; guidelines de la page `↳ Text inputs` complétées (règle, contrastes, extrait CSS).
- Repo : spec `text-input` (section dédiée + code CSS), renvoi dans les 5 autres specs, `design-system-ai-guidelines.yaml` (`Field_text`), `accessibility.yaml`.

## 2026-11-07 (7) — Promotion de composants ASMA OS vers asma.ds

Les composants suivants, génériques, passent de la section ASMA OS au design system. Ils sont **déplacés** (pas dupliqués) : les instances des maquettes OS suivent, seul le nom change (préfixe `OS / ` retiré).

- `OS / List-group-header` → `List-group-header` (page `↳ List-group-header`). Libellé + compteur ; tâches, notes, ressources, notifications, recherche, corbeille.
- `OS / Card` → `Card-collection` (page `↳ Card-collection`), distinct de `Card` qui reste inchangé. `OS / BlockHeader` → `Block-header` (déplacé avec : dépendance de `Card-collection`). `OS / Card-item / {Note, Tâche, Contact, Relation, Information, Projet}` → `Card-item / …` (6 patrons, noms français conservés ; `Projet` ajouté à la liste demandée).
- Nouveau composant `Search-results` (page `↳ Search-results`) : panneau déroulant de résultats groupés, construit à partir du cadre `searchResults` de la recherche globale desktop (3 groupes en exemple, `Show-footer`, `Footer-label`, `Footer-hint`). Distinct de `Command`.
- Specs créées : `components/list-group-header/`, `components/card-collection/`, `components/search-results/` ; `README.md` et `decisions.yaml` mis à jour. Textes de guidelines de la section OS corrigés (noms des composants promus). Aucun token créé.
- Page `↳ Empty-state` replacée dans l'ordre des pages après `↳ Drawer`.

## 2026-11-07 (6) — Dialog-toolbar : règles documentées

- Spec `dialog` : règles des trois actions (`Action-1` action d'état Outlined libellé + icône ; `Action-2` action secondaire Outlined icône seule ; `Delete` Destructive plein, icône seule, toujours à droite) et règle « pas de barre dans les formulaires de création » (`Show-toolbar=false`).
- Figma : section `Dialog-toolbar` ajoutée aux guidelines de la page `↳ Dialog` (aucun changement de composant).

## 2026-11-07 (5) — Button : Pressed (bouton à bascule)

- Figma : nouvelle propriété de variante `Pressed` (False / True) sur `Button`, 10 variantes ajoutées (`Outlined` et `Ghost` × 5 State en `Pressed=True`), ComponentSet de 30 à 40 variantes. Les 30 variantes existantes passent en `Pressed=False`.
- `Pressed=True` : fond `Action/neutral-hover` (Default, Focus) ou `Action/neutral-active` (Hover, Active), Disabled inchangé. Correspond à `aria-pressed="true"`. Aucun token créé.
- Guideline : « icône pleine = actif » (Weight=Light → Weight=Fill, même pictogramme ; étoile, épingle).
- Spec `button` et guidelines de la page `↳ Button` mises à jour.

## 2026-11-07 (4) — Nouveau composant Empty-state

- Figma : page `↳ Empty-state`, ComponentSet `Empty-state` (2 variantes : `Size` Compact / Page). Propriétés `Title`, `Description`, `Show-icon`, `Show-action` ; instances exposées `Empty-icon` (Icon, défaut Tray) et `Action` (Button : Outlined en Compact, Primary en Page).
- Compact : 280 px, icône 24, padding `component-lg`. Page : 480 px, icône 32, padding `component-xl`. Textes : Title `Misc/Label` / `Heading/SM`, Description `Body/MD` / `Body/LG`.
- Tokens `Text/primary`, `Text/secondary`, `Icon/tertiary`, `Spacing/component-*`. Aucun token créé.
- Spec `components/empty-state/empty-state-component-spec.md` créée ; `decisions.yaml`, README, `patterns/README.md` et le pattern Filter bar (cas « zéro résultat ») mis à jour.

## 2026-11-07 (3) — Nouveau composant Banner

- Figma : page `↳ Banner`, ComponentSet `Banner` (8 variantes : `Status` Info/Success/Warning/Danger × `Form` Inline/Page). Propriétés `Message`, `Show-icon`, `Show-action-1` (true), `Show-action-2` (false), `Show-close`. Actions = instances de `Button` (Outlined, Ghost).
- `Inline` : arrondi `Radius/control`, bordure sur 4 côtés. `Page` : pleine largeur, angles droits, bordure inférieure seule, sous la barre du haut.
- Tokens `Feedback/{Status}/background|border|text|icon`. Aucun token créé.
- Spec `components/banner/banner-component-spec.md` créée (distinction Banner / Alert / Toast, hauteur, accessibilité).

## 2026-11-07 (2) — Chip : types alignés sur Tag

- Figma : le `Chip` reprend les 6 `Type` de `Tag` — ajout de `Info`, `Success`, `Warning`, `Danger` (48 variantes, ComponentSet de 24 à 72). Default/Hover : bordure `Feedback/{statut}/border`, texte et icônes `Feedback/{statut}/text` ; Active : fond `Feedback/{statut}/background`, sans bordure ; Disabled : gris commun. Propriétés `Label`, `Show-icon-leading`, `Show-icon-trailing` rebranchées sur les 48.
- Spec `chip` mise à jour (Type, couleurs, Active, contrastes) ; guideline Figma de la page `↳ Chip` corrigée (72 variantes, State).
- Aucun token créé.

## 2026-11-07 — Tokens Data-viz

- **Tokens** (Semantic, 19) : `Data-viz/series/1` à `6` (palette catégorielle, Light et Dark), `Data-viz/sequential/100` à `900` (rampe à une teinte, Blue : en Dark le pas N pointe `Blue/(1000 − N)`, donc le numéro désigne toujours l'intensité), `Data-viz/gridline`, `Data-viz/axis-label`, `Data-viz/current-period`, `Data-viz/highlight`. CSS : `--color-data-viz-series-1`, `--color-data-viz-sequential-100`, `--color-data-viz-gridline`…
- **Renommage** : `Chart/series-1` à `5` (créés le 2026-11-02, jamais utilisés) deviennent `Data-viz/series/1` à `5` ; valeurs inchangées. Le groupe `Chart` disparaît.
- **Primitive** (11 nouveaux) : famille `Color/Fuchsia/50` à `950` (ancre `#C026D3` au 600), utilisée uniquement par `Data-viz/series/6` — aucune des six familles existantes ne donne une sixième teinte chromatique distincte (le gris échoue au seuil de chroma). Série 6 : Fuchsia/600 en Light, Fuchsia/500 en Dark.
- **Validation** (script dataviz) : bande de luminosité, chroma, écart en vision normale (pire paire adjacente 17,4) et contraste ≥ 3:1 sur la surface OK en Light et en Dark ; écart daltonien entre séries adjacentes 6,2 (zone plancher) : encodage secondaire obligatoire (légende, étiquettes directes ou tableau).
- **Build** : `scripts/build_css.py` gère le préfixe `Data-viz` (`--color-data-viz-…`) ; `dist/tokens.css` régénéré.
- Docs : `guidelines/foundations.yaml` (bloc `data_viz`, remplace `chart_palette`) et `guidelines/design-system-ai-guidelines.yaml`.

## 2026-11-06 (1) — Drawer : Dialog-toolbar et Show-toolbar

- Figma : nouveau composant `Dialog-toolbar` (page `↳ Dialog`) — 3 booléens `Show-action-1`, `Show-action-2`, `Show-delete` ; nouvelle propriété `Show-toolbar` (Boolean, `false`) sur le ComponentSet `Drawer` (3 `Position`). Zone fixe entre `Dialog-header` et `Dialog-body`. `Dialog-header` : padding bas à 16 px.
- Spec `dialog` (section Dialog-toolbar, padding de l'en-tête) et spec `drawer` (propriété `Show-toolbar`). Aucun token créé.
- Figma : `Dialog-toolbar` sans bordure (haute et basse retirées), fond `Background/subtle` → `Background/sunken` ; hauteur 70 → 68 px. Spec `dialog` alignée.
- Figma : composant `Drawer/Bottom` (480 px, jamais instancié) supprimé ; la variante `Position=Bottom` du ComponentSet `Drawer` (900 px) reste. La `Dialog-toolbar` est en `FILL` dans les 3 `Position` (suit la largeur du panneau, vérifié par redimensionnement).
- Spec `dialog` : `Dialog-footer` sans bordure haute (alignée sur Figma), padding 8 / 16 / 16 / 16.
- Figma : `minHeight = 44` sur les 30 variantes du `Button` (un bouton sans libellé ne retombe plus à 40 px de haut). Un carré 44×44 reste à régler par instance (`Icon-only` + taille fixe).

## 2026-11-02 (9) — Button : Type Destructive-ghost

- Figma : nouveau Type `Destructive-ghost` dans le ComponentSet `Button` (5 variantes `State`, 25 → 30 variantes). Transparent, texte `Feedback/Danger/text`, icônes `Feedback/Danger/icon`, fonds Hover/Active/Focus repris de `Ghost` (`Action/ghost-hover` / `-active`). Aucun token créé. Guidelines de la page `↳ Button` mises à jour.
- Spec `button` : tableau des Types, section Destructive-ghost (contrastes, exception de nommage Danger/Action, limite Dark du survol).

## 2026-11-02 (8) — Toast : marge mobile

- Spec `alert` (section Toast) : marge mobile fixée à 20 px (`bottom: 20px`, centré) ; desktop confirmé (coin droit, 40 px). `Header-row` de `Table (example)` conservé tel quel.

## 2026-11-02 (7) — Palette de graphiques, Drawer carré, Textarea en FILL, slot Dialog-body, Table, TextInput

- **Tokens** (5 nouveaux, Semantic) : `Chart/series-1` à `Chart/series-5` — couleurs catégorielles de séries de graphique, alias de primitives existantes. Light : `Blue/500`, `Red/600`, `Cyan/600`, `Green/600`, `Amber/600` ; Dark : `Blue/400`, `Red/500`, `Cyan/600`, `Green/600`, `Amber/600`. Validées (bande de luminosité, chroma, plancher de vision normale 17,4, contraste ≥ 3:1) ; séparation daltonisme adjacente 6,2 (plancher) → encodage secondaire obligatoire (légende, étiquettes directes ou tableau). Figma (variables), `tokens/semantic.json`, `dist/tokens.css` (régénéré), `foundations.yaml` (`color.chart_palette`) et guidelines IA mis à jour.
- **Drawer** : coins carrés partout — le conteneur (3 `Position` + `Drawer/Bottom`) n'a plus d'arrondi ; les `Dialog-header` / `Dialog-footer` y restent à 0. Spec `drawer` réécrite en conséquence.
- **Textarea** : le composant garde 280 px par défaut, `field` passe en `FILL` en largeur (32 variantes).
- **Dialog-body** : `clipsContent: false` documenté sur le composant et le `slot` (déjà appliqué dans Figma) pour que le focus des champs reste visible.
- **Table** : élévation 0 documentée (aucun effet dans Figma).
- **TextInput** : hauteur 44 px actée comme définitive (40 px abandonné).
- **KPI** : aucune modification — `Show-delta` est déjà documenté.

## 2026-11-02 (6) — Toast : placement

- Spec `alert` (section Toast) : placement desktop (coin droit, `bottom: 40px` par défaut ou `top: 40px`) et mobile (centré en bas), adaptation aux zones fixes pour que le toast reste visible. Guideline Figma de la page `↳ Toast` alignée. Aucun composant modifié.

## 2026-11-02 (5) — Dialog-header / Dialog-footer sans arrondi dans un Drawer

- Figma : les instances `Dialog-header`, `Dialog-body` et `Dialog-footer` des composants `Drawer` (3 `Position` + `Drawer/Bottom`) ont leurs 4 coins à 0 (override de l'instance) ; l'arrondi propre au conteneur `Drawer` (coins côté contenu) est inchangé.
- Spec `drawer` : nouvelle section « Dialog-header / Dialog-footer dans un Drawer » ; spec `dialog` : renvoi. Guideline Figma de la page `↳ Drawer` mise à jour.

## 2026-11-02 (4) — Contraste Dark Destructive, Dialog, noms de calques génériques, règles Body/2XS et Border/subtle

- **Tokens** : `Action/destructive`, `-hover`, `-active` en Dark passent de `Red/500`/`600`/`700` à `Red/600`/`700`/`800` (valeurs Dark = valeurs Light). Contraste `Text/on-brand` sur le fond : 3,76:1 → 4,83:1. Mis à jour dans Figma (alias), `tokens/semantic.json` et `dist/tokens.css`.
- **Dialog** : `Dialog-header` (coins hauts) et `Dialog-footer` (coins bas) en `Radius/card` (variable liée), `clipsContent: false` conservé ; mention « À valider » retirée de la spec.
- **Noms de calques** : les noms génériques à un mot sont en minuscule dans les specs (`header`, `footer`, `body`, `track`, `fill`, `indicator`, `row`, `arrow`, `marker`, `rail`, `content`, `tools`, `note`, `media`, `ports`, `connector`, `weekN`, `innerTooltip`, `frame85`). Instance `Search-button` → `searchButton` (exception voulue ; les autres instances, comme `Header-cell`, `Cell`, `Row`, gardent le nom de leur composant) ; `[field, searchButton]` dans la spec Search. Textes des guidelines Figma alignés (Calendar, Card, Command, Image, KPI, Lang/Theme switcher, Node, Numeric inputs, Popover, Progress, Skill, Step indicator, Text inputs, Timeline, Tooltip).
- **Règles** : `Body/2XS` uniquement quand il n'y a pas d'autre choix (seul usage : Count ExtraSmall) ; `Border/subtle` = bordure surtout cosmétique à contraste faible assumé, `Border/default` quand la bordure doit rester bien visible.

## 2026-11-02 (3) — Button : Type=Danger renommé Destructive

- Figma : la valeur de variante `Type=Danger` du `Button` devient `Type=Destructive` (5 variantes, aucun changement visuel ; les instances suivent). Aligné sur le token `Action/destructive` et la règle « Destructive is an action ; Danger is feedback ».
- Spec `button` et `design-system-ai-guidelines.yaml` mis à jour. Aucun token modifié.

## 2026-11-02 (2) — Calques de mise en page en lowerCamelCase

- Convention : les calques de mise en page à l'intérieur des composants (frames, auto-layouts, slots, groupes) sont en lowerCamelCase. Composants, variantes (`Type=Primary`), propriétés (`Show-label`), instances et textes gardent leurs noms. Règle ajoutée à `foundations.yaml` (`naming.layers`) et aux guidelines IA.
- Figma : 914 calques renommés dans les composants du DS (hors prototypes, guidelines de pages et cover, laissés tels quels). Exemples : `Field` → `field`, `Value-row` → `valueRow`, `Select-cell` → `selectCell`, `Header-row` → `headerRow`, `Cell-active` → `cellActive`, `InnerTooltip` → `innerTooltip`, `Frame 85` → `frame85`, `CTA` → `cta`, `Pagination — Simple` → `paginationSimple`.
- Specs mises à jour : les noms de calques distinctifs cités entre accents graves (`Field`, `Cells`, `Select-cell`, `Header-row`, `Value-row`, `Cell-*`, `Weekday-row`, `Days-grid`, `Shortcut-badge`, `Workspace-header`) passent en lowerCamelCase. Les noms génériques d'un seul mot (`Header`, `Body`, `Footer`, `Row`, `Track`, `Fill`…) peuvent encore apparaître avec une majuscule dans les specs quand ils désignent aussi un composant ou une propriété : à relire au fil des prochaines modifications.
- À valider : les `Cell-*` du ThemeSwitcher / LangSwitcher et `Row` / `Cells` du Table sont des calques, pas des composants : vérifier que les specs n'ont pas confondu un nom de calque et un nom de composant.

## 2026-11-02 — Dialog et Textarea : ligne de détourage et clipsContent

- Specs `dialog` et `textarea` : la règle déjà notée pour `TextInput` (Focus en `strokeAlign: OUTSIDE`, parents sans `clipsContent`) y est reportée. Aucun changement Figma nécessaire : les 32 variantes du `Textarea` et les trois briques `Dialog-*` ne clippent déjà pas.
- À valider : coins arrondis du conteneur de `Dialog` sans clip.
- À reporter dans l'artefact à la prochaine MAJ asma.ds.

## 2026-11-01 (2) — Toast : titre en Body/MD

- Figma : le `Title` du `Toast` passe de `Body/SM` (12/16) à `Body/MD` (14/20), aligné sur la taille de `Action-label`. Largeur hug 274 → 297 px, hauteur 46 px inchangée (12 instances dans les prototypes suivent).
- Spec `alert` (section Toast) mise à jour.

## 2026-11-01 — Button Type=Danger

- Figma : `Button` gagne `Type=Danger` (5 états) : fond `Action/destructive` / `-hover` / `-active`, texte et icônes `Text/on-brand` / `Icon/on-brand`, Focus = `Border/focus`, Disabled = gris commun. 25 variantes (5 Type × 5 State). Propriétés (Label, Show-*) rebranchées. Guidelines de la page `↳ Button` mises à jour.
- Spec `button` et `README.md` mis à jour. Aucun nouveau token.
- **À valider** : contraste du texte blanc sur `Action/destructive` en Dark (`Red/500`, 3,76:1 < 4,5:1).

## 2026-10-31 (4) — Table : pas de bordure sous la dernière ligne

- Règle systématique ajoutée à la spec `table` et à `decisions.yaml` : la dernière `Row` n'a pas de bordure basse (le conteneur porte déjà la bordure).
- Figma : `strokeBottomWeight=0` sur la dernière `Row` de `Table (example)` ; guideline `Row` complétée. Le composant `Row` garde sa bordure basse (le reste des lignes en a besoin).

## 2026-10-31 (3) — Boutons sans libellé restés à 40 px

- Figma : 8 boutons avaient `Show-label=false` sans `Icon-only=true` (donc 40 × 40 au lieu de 44 × 44) : les 3 boutons de `PortfolioHeader` Mode=Mobile (+ ses instances dans les prototypes et la cover), `Action-1` du guide `PageHeader` et un bouton isolé de la page `↳ Button`. Tous passés en `Icon-only=true`, 44 × 44. Contrôle : 168 boutons sans libellé dans le fichier, tous en 44 × 44.
- Spec `button` : ajout du piège (régler `Show-label`, `Icon-only` et la taille ensemble).
- À valider : l'en-tête mobile du portfolio gagne 4 px de haut.

## 2026-10-31 (2) — Sparkline : courbe stagnante

- Figma : `Sparkline` gagne `Trend=Stagnant` (4 variantes) : courbe quasi plate, centrée dans la pastille 96 × 56, couleur `Icon/secondary` comme Neutral. `Neutral` reste irrégulier (monte et descend sans tendance).
- Spec `kpi` et `decisions.yaml` mises à jour. Le `Trend` du KPI lui-même (jugement du Tag) ne change pas.

## 2026-10-31 — Picto dans le README

- `README.md` : en-tête avec le picto `assets/logo/asma-ds-profile.png` (96 px, centré) et le titre `asma.ds`. Le README ne référençait aucune image jusque-là.

## 2026-10-30 — Count ExtraSmall (12 px) et style Body/2XS

- Figma : `Count` gagne `Size=ExtraSmall` (12 px, nouveau Text Style `Body/2XS`, padding horizontal 3 px, rond parfait pour un chiffre) : 18 variantes (6 Type × 3 Size).
- `Icon` : `Bullet=Count` utilise ExtraSmall sur les tailles `Small` (16 px) et `Medium` (20 px), Small sur `Large` et `XLarge`. Débord de 4 px du coin conservé.
- Nouveau Text Style `Body/2XS` (Inter Regular 8/12, lié aux variables Responsive `Typography/body-2xs/Font-size` et `/Line-Height`, valeurs directes 8 et 12 : aucun pas Primitive ne correspond). Réservé à la valeur du Count ExtraSmall. Reporté dans `tokens/responsive.json`, `dist/tokens.css`, `foundations.yaml`.
- Specs mises à jour : `count`, `icon`.

## 2026-10-29 (5) — Tous les champs de saisie à 44 px

- Figma : `OTP-cell` (donc `Code-OTP`), `Duration-segment` et `Stepper` passent de 40 à 44 px de haut (cases 44×44 ; Stepper 44, boutons − / + en 44×44). `Search-button` passe de 40×40 à 44×44 pour s'aligner sur le champ. `TextInput`, `PasswordInput`, `Search`, `Select` et `TagInput` étaient déjà à 44 px (spec TextInput corrigée) ; `Textarea` reste à 160 px.
- Specs corrigées : `text-input` (44 px, la spec disait 40), `search-input`, `code-otp`, `duration-input` (case 44×44, la spec disait 48×40), `stepper`, `DESIGN.md` (hauteur standard 44 px).
- `Button` : l'exception « bouton sans libellé dans un champ reste 40×40 » est supprimée, la règle 44×44 est générale.
- `Stepper` : la bordure (toujours présente dans les trois états) n'entre plus dans la mise en page (`strokesIncludedInLayout: false`) ; la zone de la valeur passe de 42 à 44 px de haut, comme les boutons, et la largeur est la même dans les trois états (136 px).
- `tag-input` : la note sur l'écart avec la spec TextInput est résolue. **À valider** : la largeur de la cellule `Duration-segment` (maintenant 44).

## 2026-10-29 (4) — Button sans libellé : 44×44 fixe

- Nouvelle règle (`components/button/button-component-spec.md`) : un Button sans libellé garde la hauteur de 44 px et une largeur fixe de 44 px (taille `FIXED`, icône centrée). Remplace le gabarit 32×32 (padding `component-xs`) de l'ancienne convention.
- Figma : 34 instances `Icon-only=true` passées en 44×44 fixe (`↳ Cell`, `↳ Table`, `↳ Pagination`, `↳ Dossier de compétences`, `Prototypes`, exemple de `↳ Count`). Exception : les boutons dans les champs (`↳ Text inputs`, `↳ Numeric inputs`, 38 instances) restent 40×40.
- Effets de bord : les rangées `Pagination` passent de 40 à 44 px de haut ; dans `Prototypes`, deux `Page-header` gagnent 4 px et une `App-bar` 4 px.
- Correction de la spec : la hauteur du Button avec libellé est 44 px (la spec disait 40 px).
- **À valider** : `README.md` indique encore « 40px » pour la hauteur des contrôles sur une ligne (bouton et champ) ; vrai pour les champs, pas pour le bouton. Les boutons sans libellé hors `Icon-only` (ex. `↳ Portfolio`) n'ont pas été modifiés.

## 2026-10-29 (3) — Le Count prend la place du Dot Indicator

- `Icon` : nouvelle valeur `Bullet=Count` (16 variantes : 4 Size × 4 BulletPosition). Le Count (Danger, Small par défaut) occupe le slot du Dot, déborde de 4 px du coin de l'icône ; l'instance imbriquée `Count` est exposée (valeur, Type). `ComponentSet` Icon : 20 → 36 variantes. Les variantes existantes sont inchangées.
- Specs `Icon`, `Dot Indicator`, `Count` et `decisions.yaml` : règle « quantité pertinente → Count à la place du Dot ; jamais les deux ».
- **À valider** : Count Small (16 px) sur une icône Small (16 px) la recouvre en grande partie.

## 2026-10-29 (2) — Nouveau composant Count

- `components/count/count-component-spec.md` : composant Count (page Figma `↳ Count`), 12 variantes (Type Neutral/Brand/Info/Success/Warning/Danger × Size Medium 20 px / Small 16 px), propriété texte `Value`. Même mapping couleur que `Tag`, `Body/SM` et `Body/XS`, `Radius/pill`, `Spacing/component-2xs`. Aucun nouveau token.
- Plafond `99+`, masqué à 0, Small réservé à la superposition sur une icône.
- `decisions.yaml` : entrée `Count`. `design-system-ai-guidelines.yaml` et `README.md` : composant ajouté à la liste.
- Les mentions « Badge » des specs `Dot Indicator` et `Icon` (et du texte Figma de la page Dot indicator) pointent maintenant vers `Count`.
- **À valider** : hauteurs 20 / 16 px en valeurs littérales ; lisibilité de `Body/XS` en Small.

## 2026-10-29 (2) — TagInput : hauteur 44, Clear-all à droite, comportement d'autocomplétion

- **Composant** (Figma, 32 variantes) : hauteur minimale du `Field` 40 → **44px**, alignée sur les autres champs ; contenu centré verticalement. `Clear-all` en position absolue, ancré à droite et centré (contraintes droite / centre) ; padding droit du `Field` 8 → 32px pour lui réserver la place. Aucun nouveau token.
- **Comportement documenté** (spec `components/tag-input/`) : liste de suggestions au focus et à la saisie, autocomplétion insensible à la casse et aux accents, option « Créer « … » » quand aucune valeur ne correspond exactement, doublons évités, garde-fou métier optionnel, clavier, accessibilité (combobox / listbox).
- **Liste de suggestions** : composition de `Select-option` documentée (pas de composant Listbox dédié pour l'instant).
- **Règle générale** (spec TextInput + `guidelines/agent.yaml`, `known_constraints.input_focus_ring_clip`) : ne jamais rogner les conteneurs d'un champ, la bordure Focus étant dessinée à l'extérieur. Ajout aussi de `slot_content_lazy_traversal` (contenu d'un slot invisible au premier parcours après un clonage).
- Figma : bloc « TagInput » ajouté aux guidelines de la page `↳ Text inputs` + section de référence « TagInput — comportement (autocomplétion & création) » (8 états).
- **À valider** : élévation de la liste de suggestions (`Elevation/2` proposé) ; hauteur des champs dans la spec TextInput (40px écrit, 44px mesuré dans Figma).

## 2026-10-29 — Champs de saisie : bordure Default en `Border/subtle`

- Tous les champs en `Interaction=Default` / `Validation=None` passent de `Border/default` à `Border/subtle` (Figma : TextInput, PasswordInput, Search, Textarea, Select, TagInput, OTP-cell, Duration-segment, Stepper ; 17 variantes). Hover (`Border/strong`), Focus, Disabled et les états de validation sont inchangés. Aucun nouveau token.
- Spec : `components/text-input/text-input-component-spec.md`.
- **À valider** : contraste de la bordure (`Border/subtle`) sur le fond du champ, en Light et en Dark.

## 2026-10-28 (5) — Logo asma-ds : image de profil (PNG)

- Ajout de `assets/logo/asma-ds-profile.png` (1024×1024, fond transparent aux coins) : export du `picto` `asma-ds` de la page Figma `↳ Logos` (tuile `Feedback/Info/background`, forme `Icon/primary`, thème Light).

## 2026-10-28 (4) — Heading/LG : line-height 32

- `Typography/heading-lg/Line-Height` passe de 40 (`6xl`) à 32 (`5xl`) en Mobile et Desktop (Figma, `tokens/responsive.json`, `dist/tokens.css`, `foundations.yaml`, `design-system-ai-guidelines.yaml`). Le Text Style `Heading/LG` suit (28/32 en Mobile, 32/32 en Desktop). Aucun nouveau token.
- **À noter** : en Desktop, taille et interligne sont égaux (32/32) ; à vérifier sur les titres de 2 lignes.

## 2026-10-28 (3) — DA : pictogrammes et logos remplacent les doodles (STYLE.md)

- `STYLE.md` mis à jour d'après la page Figma `↳ Logos` et la cover : nouveau §6 « Pictogrammes et logos » (`picto` 80×80, 8 variantes : 3 marques `concatenation` / `asma-ds` / `asma-os` + 5 pôles ; tuile `Feedback/Info/background`, glyphe `Icon/primary`, coins `Radius/card` ; lockups `logo / concatenation`, `logo / asma-ds`, `logo / asma-os` = `picto` 32 + wordmark vectoriel, gap 8).
- Cover (§7) : grille de 8 `picto` 160×160 pivotée de 5° à la place des deux bandes de doodles (conservées dans le fichier, masquées). Bloc titre inchangé.
- Doodles passés en historique (§6 bis) ; la dalle cyan littérale (`#cffafe` / `#18fefe`) n'est plus une règle : la tuile des pictogrammes est liée à une variable.
- §1, §2, §8 et §9 alignés ; §10 signale que `Cover/preview.html` (entête de l'artefact) reproduit encore l'ancienne DA.
- **À valider** : sort des doodles (supprimer ou archiver), renommage de la propriété `Property 1` de `picto`, marges de protection des logos.

## 2026-10-28 (2) — Élévation plus douce (valeurs de Frame 225)

- Les 5 Effect Styles `Elevation/1` à `5` passent de deux ombres avec étalement négatif à **une seule ombre douce, sans étalement**, toutes colorées par `Shadow/subtle` : 1 → `0 5 10`, 2 → `0 10 25`, 3 → `0 20 50`, 4 → `0 32 70`, 5 → `0 50 100` (x y flou).
- Valeurs reprises de la frame de référence `Frame 225` (flat, overlay, sticky-nav, dialog) pour les niveaux 1, 2, 3 et 5 ; le niveau 4 (Drawer) est calculé entre les niveaux 3 et 5. Le niveau 4 est la seule valeur non dessinée.
- `Shadow/strong` n'est plus utilisé par les niveaux (conservé pour l'instant). La couleur d'ombre reste `Color/Neutral/950` à 10 % (Light) / 35 % (Dark), pas le `#141414` de la référence.
- Mis à jour : page Figma `↳ Elevation` (textes et tableau), `foundations.yaml` (`elevation`).

## 2026-10-28 — KPI : nouveau composant, minicourbe et chargement

- Nouveau composant `KPI` (page Figma `↳ KPI`), construit à partir du design de l'utilisateur (frames `KPI / Desktop` et `KPI / Mobile` converties en ComponentSet) : `Icon` Small + `Label`, `Value` en `Display/SM`, `Tag` Small pour la variation et `Caption`.
- 12 variantes : `Device` (Desktop 280 px / Mobile 160 px, grille 2 colonnes d'un écran 360) × `Trend` (Neutral / Positive / Negative = `Type` du Tag Neutral / Success / Danger + flèche ; jugement, pas direction) × `State` (Default / Loading). `Device` fixe le mode Responsive.
- **Minicourbe** : nouveau sous-composant `Sparkline` (variant `Trend`), présenté en pastille (fond `Background/subtle`, radius `Radius/card`, padding `Spacing/component-sm`, tracé 72 × 32 en `Border/medium` coloré `Feedback/Success/icon` / `Feedback/Danger/icon` / `Icon/secondary`), propriété `Show-chart` (défaut `false`). À droite de la valeur en Desktop (96 × 56), sous la valeur en Mobile (pleine largeur × 56). Décorative ; tracé Figma indicatif, vraies données en code.
- **Chargement** : `State=Loading` remplace chaque élément par une instance `Skeleton` (Circle / Text / Rectangle) aux hauteurs exactes de l'état Default (aucun décalage). `Trend` sans effet dans cet état.
- Microcopy française conservée dans les défauts et les exemples : `+8,2 %`, `−3,1 %`, `0,0 %`.
- Propriétés : `Label`, `Value`, `Caption` (Text), `Show-icon` / `Show-delta` / `Show-caption` / `Show-chart` (Boolean), instances exposées `Icon` (Instance-swap) et `Tag`.
- Spec `components/kpi/kpi-component-spec.md` ; entrée `KPI` dans `decisions.yaml`. Aucun token créé. Exemples Desktop, Mobile et Chargement sur la page Figma.
- Contrastes du trait de la minicourbe sur `Background/subtle` (Light / Dark) : Success 3,15 / 9,34, Danger 4,62 / 5,88, Neutral 7,24 / 6,34 — tous ≥ 3:1.
- **À valider** : forme du tracé placeholder.

## 2026-10-27 (4) — Icônes : graisse Light par défaut

- Convention : les icônes d'interface (Phosphor, `Format=Outline`) utilisent **`Weight=Light`** par défaut (avant : Regular). Mis à jour dans `foundations.yaml` (`icons.weight`), le guide IA et les specs Icon, Button, Theme switcher et Pagination.
- Figma : toutes les instances `Weight=Regular` passées en `Weight=Light` (composants, patterns, Userflow, Prototypes, Dossier de compétences, Portfolio) via la propriété Instance-swap du wrapper `Icon` ; défaut du composant `Icon` = `Acorn` Light ; glyphes Checkbox, PasswordInput et Line migrés directement. Couleurs liées aux variables conservées.
- Inchangés : 32 icônes `Weight=Thin` et 2 `Fill` déjà présentes dans Dossier de compétences / Portfolio.

## 2026-10-27 (3) — Voile (scrim) : token Shadow/scrim et règle (proposition)

- **1 nouveau token Semantic** `Shadow/scrim` : Light → `Color/Shadow/35` (35 %), Dark → `Color/Shadow/60` (60 %). Aucune nouvelle Primitive. `--color-shadow-scrim`. Portée Figma : remplissages (frame / forme), pas un Effect Style.
- Règle (`foundations.yaml` → `elevation.scrim`) : voile uniquement derrière les overlays modaux bloquants (niveaux 4–5 : Drawer modal, Dialog, Command) ; aucun voile pour les niveaux 1–3 ; ordre contenu < voile < overlay ; un seul voile à la fois ; clic sur le voile ou Échap ferme sauf overlay bloquant ; contenu sous le voile inerte ; voile décoratif (`aria-hidden`) ; apparition en opacité avec les tokens Motion existants.
- Page Figma `↳ Elevation` : aperçus Light / Dark du voile sous un Dialog (niveau 5).
- **À valider** : opacités 35 % (Light) / 60 % (Dark), Drawer toujours modal ou non.

## 2026-10-27 (2) — Elevation : 5 niveaux et tokens Shadow (proposition)

- Page Figma `↳ Elevation` (Foundation) : 5 Effect Styles `Elevation/1` à `Elevation/5` (deux ombres chacun) et aperçus Light / Dark. Niveaux : 1 Raised (Card), 2 Floating (Popover, Menu, Select, Tooltip), 3 Overlay (Toast), 4 Panel (Drawer), 5 Modal (Dialog, Command).
- **4 nouvelles Primitive** `Color/Shadow/10`, `/20`, `/35`, `/60` = `Color/Neutral/950` (`#020617`) à N % d'opacité (hex à 8 chiffres : `#0206171a`, `#02061733`, `#02061759`, `#02061799`). Dérogation assumée à l'échelle 50–950 : le palier est le pourcentage d'opacité.
- **2 nouveaux tokens Semantic** : `Shadow/subtle` (Light → `Color/Shadow/10`, Dark → `/35` ; niveaux 1–2) et `Shadow/strong` (Light → `/20`, Dark → `/60` ; niveaux 3–5). Portée Figma `EFFECT_COLOR`. CSS : `--color-shadow-subtle`, `--color-shadow-strong` (`dist/tokens.css` régénéré). Nouveau groupe `Shadow` dans `foundations.yaml` (`semantic_roles`) et section `elevation`.
- Les Effect Styles sont liés aux tokens ; le niveau est porté par le décalage, le flou et l'étalement (niveaux 3–5 resserrés pour compenser l'opacité unique).
- **À valider** : rattachement des composants aux niveaux, surfaces Dark par niveau, scrim des overlays. Aucun composant n'utilise encore ces styles.

## 2026-10-21 (2) — Tag Neutral : nouveau token Background/strong

- Nouveau token Semantic **`Background/strong`** : Light → Neutral/200 (`#e2e8f0`), Dark → Neutral/700 (`#334155`). `--color-background-strong` dans `dist/tokens.css` (régénéré).
- `Tag` `Type=Neutral` : fond `Action/neutral` → `Background/strong` (contre la page : 1,10 → 1,23:1 Light, 1,22 → 1,72:1 Dark ; texte `Text/primary` 14,5:1 / 9,9:1). Statuts et Brand inchangés. Spec Tag, `foundations.yaml`, `design-system-ai-guidelines.yaml` et `DESIGN.md` mis à jour.

## 2026-10-21 — Timeline : suivi du scroll

- `Timeline` : nouveau comportement documenté (section « Suivi du scroll » + « États (connecteur) » dans `timeline-component-spec.md`). Ligne de repère fixe à 36 % de la hauteur de la fenêtre (décision du 2026-10-21, plus calée sur le premier marqueur), actif = dernier marqueur au-dessus de la ligne (aucun actif tant qu'aucun n'a atteint la ligne), connecteur rempli en continu en `Action/primary` et reste plein une fois passé, anneau sur les marqueurs passés. Seul l'élément actif porte le rendu `Current` (pas d'état `Active` distinct). Aucun changement Figma ni token.

## 2026-10-15 (3) — Skill Desktop : Progress dans le header

- `Skill` `Device=Desktop` : `Progress` déplacée dans le `Header`, entre `Label` et `Note` (120px fixe) ; `Label` tronqué. Mobile inchangé (barre sous le header). `Note` : `minWidth` 150px (Desktop et Mobile). Spec et guidelines Figma mises à jour.

## 2026-10-15 (2) — Skill Mobile : libellé tronqué

- `Skill` `Device=Mobile` : `Header` en ligne (flex row, comme Desktop), `Label` en `FILL` tronqué sur une ligne (ellipse), `Note` à droite. Spec `skill-pattern-spec.md` et guidelines Figma mises à jour.

## 2026-10-15 — Border/subtle : contraste rehaussé

- `Border/subtle` Light : Neutral/100 → **Neutral/300** (`#cbd5e1`) — 1.48:1 sur `default`, 1.42:1 sur `subtle` (auparavant 1.1:1 et 1.05:1, presque invisible). Neutral/200 écarté : identique à `Border/disabled`.
- `Border/subtle` Dark : Neutral/700 → **Neutral/600** (`#475569`) — 2.36:1 sur `default`, 2.15:1 sur `subtle`, 1.93:1 sur `elevated` (auparavant 1.72, 1.57, 1.41).
- Reste en dessous de `Border/default` (Neutral/500). Appliqué dans Figma (variable Semantic), `tokens/semantic.json` et `dist/tokens.css` régénéré. Affecte tout ce qui utilise `Border/subtle` (Table, Skill, séparateurs…).

## 2026-10-14 (2) — Timeline-item : outils (Show-tools)

- `Timeline-item` : bloc `Tools` sous `Description` (booléen `Show-tools`, `false` par défaut) avec `Tool-1..5` (`Tag` Neutral Medium, exposés, `Show-tool-1..5`), comme sur le pattern `Skill`. 4 variantes. Spec `timeline-component-spec.md` mise à jour.

## 2026-10-14 — Pattern Skill (ComponentSet Mobile/Desktop)

- Nouveau **pattern `Skill`** (page Figma `↳ Skill`, section `💻 PATTERNS`) : ligne de compétence couvrant les sections « Cartographie de compétences » et « Outils & technologies » de `About / Desktop`, au style de la Row « Outils & technologies » (vertical, bordure basse `Border/subtle`).
- ComponentSet `Device=Desktop|Mobile` ; propriétés `Label`, `Score`, `Description` (Text), `Show-score`, `Show-level`, `Show-progress`, `Show-description`, `Show-tools`, `Show-tool-1..5` (Boolean) ; instances exposées `Level` (Tag), `Progress` (Progress-linear), `Tool-1..5` (Tag). La note = Score + Level + Progress.
- Spec `patterns/skill/skill-pattern-spec.md`, entrée `Skill` dans `decisions.yaml`, ligne dans `patterns/README.md`. Aucun token nouveau. Page Figma : sections Skill, Exemples (cartographie, outils, complète, mobile) et Guidelines.
- Non fait : remplacement des lignes existantes de la page Portfolio par des instances de `Skill`.

## 2026-10-13 (5) — Entête de l'artefact alignée sur la cover

- Entête (`Cover/preview.html`) de l'artefact asma.ds redessinée d'après la cover Figma (`STYLE.md` §7). Nouvelle section `STYLE.md` §10 qui la décrit. Aucun token modifié.

## 2026-10-13 (4) — Breadcrumb : spec, correctifs et entrée dans le repo

- **Breadcrumb** (composant déjà construit dans Figma, page `↳ Breadcrumb`) : spec `components/breadcrumb/breadcrumb-component-spec.md`, entrée `Breadcrumb` dans `decisions.yaml`, ligne dans le README.
- **Correctifs Figma** : Text Style `Body/MD` appliqué (texte sans style auparavant : JetBrains Mono 12 en capitales) ; niveaux 1 à 3 = instances exposées de `Link` (les propriétés `Level-1/2/3` sont supprimées, le libellé se modifie sur l'instance) ; page courante en `Text/secondary` au lieu de `Text/tertiary` (contraste Dark d'environ 3,75:1 insuffisant) ; mention « page Portfolio — APropos et Asma.ds » retirée des guidelines.
- Section d'exemples `Exemples` ajoutée sur la page Figma `↳ Breadcrumb` (fil à 4 niveaux et fil à 2 niveaux au-dessus d'un titre de page).
- **Comportement écran étroit** : `layoutWrap = WRAP` (gap de lignes `component-2xs`), instance en `FILL` dans son conteneur ; `Level-4` en `FILL`, min. 160px, une ligne avec ellipse. Exemple `Exemple — Mobile, intitulés longs` (frame 360px) : le fil passe sur 3 lignes, la page courante reste visible. Aucun nouveau token ; réduction « … » des niveaux intermédiaires non retenue.

## 2026-10-13 (3) — Toast et Menu-item : espacements hors échelle liés aux tokens

- **Toast** : padding vertical 10px → `Spacing/component-sm` (12px), identique au padding horizontal. Hauteur 42 → 46px (4 variantes).
- **Menu-item** : `Indent=True`, padding gauche 32px → `Spacing/component-xl` (32px en Desktop, **24px en Mobile**). Le canvas Figma, en mode Mobile par défaut, affiche donc 24px (largeur 172 → 164px) ; ajuster si l'alignement sur 32px doit rester fixe.
- Reste en attente (catégorie B de l'audit du 2026-10-13) : 2px, 3/7/11/12px, 6px, 10px de Line.

## 2026-10-13 (2) — Figma : liaison des paddings et gaps aux tokens Spacing

- **Audit** des 36 pages de composants (paddings et gaps des auto-layouts). 273 valeurs non liées ou liées à une bibliothèque externe sont désormais liées aux variables locales : 4px → `Spacing/component-2xs`, 8px → `component-xs`, 12px → `component-sm`, 16px → `component-md`. Aucune valeur ni taille de composant modifiée (vérifié par comparaison avant/après sur chaque composant).
- Pages touchées : Calendar, Card, Command, Duration Input, Line (+ copie dans Tooltip, qui était liée à des variables d'une autre bibliothèque), Menu, Node (Port), Pagination, Selection inputs (Segmented-control), Step Indicator, Table (Header-cell), Text inputs (gaps), Timeline (gap du Rail), Tooltip.
- **Restent en dur, volontairement** (décision en attente) : 2px (gaps Card/Tag/Chip, padding du Rail de Timeline-item), 3 / 7 / 11 / 12px (paddings verticaux de Chip et des champs de saisie : probable compensation de la bordure de 1px), 6px/2px (Shortcut-badge de Command), 10px (Line, Toast), 32px (indentation du Menu-item) ; gaps de −1px de Popover/Tooltip (chevauchement voulu de la flèche).
- Non audités : page Icon, Patterns, frames d'exemple, radius et bordures.

## 2026-10-13 — Règle de choix des spacings

- **DESIGN.md** : ajout de la règle `component-*` (dans un composant) vs `section-*` (entre blocs de page), avec les chevauchements de valeurs et les assemblages manuels.
- **design-system-ai-guidelines.yaml** : `component-2xs` (4px, existant dans `tokens/responsive.json`) ajouté aux rôles responsive ; règles de choix ajoutées. Aucun token créé ni modifié.

## 2026-10-12 (3) — Progress Linear : largeur adaptable

- **Progress Linear** : le `Fill` suit désormais la largeur de l'instance (contrainte `SCALE`, `Track` sans auto-layout, `Fill` à x=0) dans les 12 variantes ; avant, sa largeur était figée en pixels (instance étirée = barre fausse). Aucun nouveau token.
- Page Figma `↳ Dossier de compétences` : les 16 instances nommées `Skill-level` (instances de `Progress-linear`) passent en `FILL` en largeur dans leur ligne.

## 2026-10-12 (2) — Timeline-item : logo

- **Timeline-item** : ajout de `Show-logo` (Boolean, défaut `false`) et d'une instance exposée de `Logos` en première position de `Content`, au-dessus de `Period` (4 variantes). Remplace le `Slot` puis le `Skeleton` essayés plus tôt le même jour (retirés). Aucun nouveau token.
- Non ajusté : alignement du `Marker` quand le logo est affiché ; propriété de variante `Property 1` de `Logos` non renommée. Le composant `Logos` (page `↳ Logos`) n'a pas encore de spec dans le repo.

## 2026-10-12 — Nouveau composant Lang switcher

- **Lang switcher** (nouveau) : basé sur `Theme switcher`, pictogrammes remplacés par des codes de langue ISO 639-1 (`FR` / `EN`) en `Body/XS` (Inter 10px). Propriétés `Lang` FR/EN × `Motion` Static/Tension × `State` Default/Hover/Disabled (12 variantes). Track 52×28, cellules 20×20 (comme Theme switcher). Réaction `CHANGE_TO` uniquement (pas de `SET_VARIABLE_MODE`). Page Figma `↳ Lang switcher` + Guidelines. Aucun nouveau token.
- **decisions.yaml** : ajout de `LangSwitcher` à `component_selection`.
- **Correctif Hover/Disabled** (Lang switcher et Theme switcher) : le contour 1px était rogné (Track 1px plus grande que le composant). `strokesIncludedInLayout = false`, Track de la taille du composant dans tous les états ; Track 52×28 pour les deux.
- Choix à confirmer : codes de langue (pas de pays), 2 langues seulement.

## 2026-10-08 — Nouveau composant Blockquote

- **Blockquote** (nouveau) : `Style` `Default` / `Accent` (2 variantes) ; propriétés `Text`, `Citation`, `Show-citation`. Barre de 4px à gauche (`Border/strong` / `Action/primary`), texte `Body/LG`, citation `Body/SM`. Page Figma `↳ Blockquote` (entre `Avatar` et `Button`) + Guidelines. Aucun nouveau token.
- **decisions.yaml** : ajout de `Blockquote` à `component_selection` ; rattrapage de `Node`, `Timeline` et `Image` (déjà publiés dans l'artefact mais absents du repo).
- Non spécifié : variante à fond, guillemets décoratifs, avatar de l'auteur, « pull quote » en `Heading`.

## 2026-10-07 (3) — Dark : échelle de surfaces Background

- **Primitive** : ajout de `Color/Neutral/850` (`#172033`), cran intermédiaire entre 800 et 900.
- **Semantic (Dark)** : `Background/sunken` → Neutral/950 (`#020617`), `Background/default` → Neutral/900 (`#0f172a`), `Background/subtle` → Neutral/850 (`#172033`, était une valeur littérale égale à 950), `Background/elevated` → Neutral/800 (`#1e293b`). Light inchangé. Avant, `default`, `subtle` et `sunken` étaient identiques en Dark (`#020617`).
- Échelle Dark : plus une surface est élevée, plus elle est claire ; `sunken` reste la plus sombre.
- `Background/disabled` (Dark, Neutral/800) est volontairement identique à `elevated` : collision acceptée. `Text/disabled` y garde 5,71:1.
- `Border/subtle` (Dark) : Neutral/800 → Neutral/700 (`#334155`) — 1,41:1 sur `elevated`, 1,57:1 sur `subtle`, 1,72:1 sur `default` (il était invisible sur `elevated`, 1:1). Identique à `Border/disabled` (Dark).
- `Icon/disabled` (Dark) : Neutral/600 → Neutral/500 (`#64748b`) — 3,07:1 sur `disabled` (était 1,93:1). Même valeur que `Icon/tertiary`, comme `Text/disabled` et `Text/tertiary` en Dark.
- `dist/tokens.css` régénéré (`scripts/build_css.py`).

## 2026-10-07 (2) — STYLE.md (identité graphique, cover)

- **STYLE.md** (nouveau, racine) : identité graphique lisible par les agents — principes, couleur, typographie, cadre de page 1920×1080, composants éditoriaux, 5 doodles par pôle, cover, do/don't. Complète `DESIGN.md` ; aucun nouveau token.
- **STYLE.md** : section Cover (bandes de doodles inclinées −12,14°, bloc titre aligné bas-droite) et dalle des doodles (cyan `#cffafe` @20 % + ombres intérieures `#18fefe` @8 %) documentées ; variantes `Doodle` : `Pole=ProductDesign` / `DesignSystem` / `UX/UI` / `Tech` / `IA`.
- Piste mezzotint abandonnée (aucun shader ni cadre de test restant dans le fichier).

## 2026-10-07 — Edge : tracé vertical

- **Edge** : `Shape=Vertical` (droite verticale) ajouté — 16 variantes (4 Shape × 4 State). Les `Handle` de `Port` restant à gauche/droite, un graphe vertical de bout en bout (prises en haut/bas) et les bézier à tangentes verticales ne sont pas spécifiés.

## 2026-10-06 (5) — Timeline horizontale, nouveau composant Image

### Composants
- **Timeline** : ajout de la propriété `Orientation` (`Vertical` / `Horizontal`) × `State` — 4 variantes au lieu de 2. Horizontale : élément de 240px, rail au-dessus du contenu, connecteur qui s'étire jusqu'à l'élément suivant ; à réserver à 3–5 étapes. Exemple Figma avec les deux orientations.
- **Image** (nouveau) : `Ratio` (`Square`/`Landscape`/`Wide`) × `State` (`Default`/`Loading`/`Error`), 9 variantes ; `Caption` + `Show-caption`. L'image est le `Fill` du calque `Media` (`Cover` pour les photos, `Contain` pour les logos). Loading au même token que `Skeleton` (`Background/disabled`). Page Figma `↳ Image` + Guidelines. Aucun nouveau token.
- **decisions.yaml** : ajout de `Image` à `component_selection`.
- Non spécifié : ratio libre, image en arrière-plan, `srcset`, lightbox ; repli responsive de la timeline horizontale. La liste de logos sera un pattern.

## 2026-10-06 (4) — Nouveau composant Timeline

### Composants
- **Timeline** (nouveau) : `Timeline-item` (brique atomique, `State` `Default`/`Current`, 2 variantes ; propriétés `Period`, `Title`, `Subtitle`, `Description`, `Show-description`, `Show-connector`) assemblé en liste verticale manuelle. Marqueur 12px + connecteur 2px (`Rail`), `Content` en `Misc/Caption` / `Misc/Label` / `Body/MD`. Pour un historique de faits datés en lecture seule (parcours professionnel, journal d'activité) — distinct de `Step-indicator` (parcours à accomplir). Aucun nouveau token. Page Figma `↳ Timeline` avec exemple d'historique d'expérience (4 postes) et Guidelines.
- **decisions.yaml** : ajout de `Timeline` à `component_selection`.
- Non spécifié : tracé horizontal ou alterné, statuts, logo d'organisation, groupement par année.

## 2026-10-06 (3) — Edge : tracés droit et descendant

- **Edge** : ajout de la propriété `Shape` (`Curve-up` / `Curve-down` / `Straight`) × `State` — 12 variantes au lieu de 4. Les variantes existantes deviennent `Shape=Curve-up`.

## 2026-10-06 (2) — Node : corrections

- **Node** : `Body` et `Ports` avaient un fond blanc par défaut qui masquait la bordure (côtés et bas) — fonds retirés. `Icon` est de nouveau une instance imbriquée de `Icon` (exposée) au lieu d'un glyphe brut lié à une propriété Instance swap ; propriété `Icon` supprimée. Ajout de `Show-input` / `Show-output` ; `Icon`, `Status-icon`, `Port-input`, `Port-output` exposés.
- **Port** : ajout des booléens `Show-label` et `Show-handle`.
- **Edge** : tirets 10/10 sur tous les états (le tiret 4/4 de `Disabled` est abandonné).

## 2026-10-06 — Nouveaux composants Node, Port, Handle, Edge

### Composants
- **Node** (nouveau) : carte de graphe de nœuds (workflow, pipeline, agents), 240px — `Header` (`Icon`, `Title`, `Status-icon`), `Body`, `Ports`. `State` (`Default`/`Hover`/`Selected`/`Disabled`) × `Status` (`None`/`Success`/`Error`), 12 variantes. Propriétés `Title`, `Description`, `Show-body`, `Icon` (Instance swap).
- **Port** (nouveau) : ligne de 24px portant un `Handle` à cheval sur le bord du nœud, `Side` (`Input`/`Output`), propriété `Label`.
- **Handle** (nouveau) : point de connexion 12px, `State` (`Default`/`Hover`/`Connected`/`Invalid`/`Disabled`), cible réelle 24×24 en code.
- **Edge** (nouveau) : liaison vectorielle 2px (bézier), gabarit de style `State` (`Default`/`Selected`/`Error`/`Disabled`) — dessinée entre les nœuds, pas étirable.
- Assemblage manuel (nombre de nœuds/ports/liaisons arbitraire), comme `Table`. Aucun nouveau token. Page Figma `↳ Node` avec exemple de graphe (4 nœuds, 3 liaisons) et Guidelines.
- **decisions.yaml** : ajout de `Node` à `component_selection`.
- Non spécifié : animation de flux, état `Running`, mini-carte, zoom/pan, regroupement.

## 2026-10-05 (4) — Resynchronisation asma.ds

### Corrections
- **Chip** : la spec indiquait encore `Action/neutral-active` pour `Active`/`Neutral`, alors que Figma (et la décision du 2026-09-28) est `Background/inverse` + `Text/inverse`. Spec réalignée ; la ligne « survol d'un Chip Active » (basée sur `neutral-active`) retirée faute de valeur vérifiée dans Figma.
- **Cell, Table** : les modifications de troncature et de fond `Background/subtle` du `Header-row` n'étaient pas présentes dans les fichiers du dossier local — réappliquées.
- **Artefact asma.ds** : ajout de `Pagination`, `Progress`, du pattern `Filter bar` ; `Cell`, `Table`, `Chip`, `Avatar` resynchronisés.

## 2026-10-05 (3) — Documentation de Progress

### Composants
- **Progress** (documenté) : `Progress-linear` et `Progress-circular` existaient dans Figma (page `↳ Progress`) sans spec dans le repo. `components/progress/progress-component-spec.md` créé à partir de l'état réel : `State` (`Determinate`/`Indeterminate`) × `Percentage` (0 à 100 par pas de 10, `none`), 12 variantes chacun. Non spécifié à ce jour : animation `Indeterminate`, `prefers-reduced-motion`, variantes de statut.
- **Guidelines Figma** de la page `↳ Progress` corrigées : anneau 48×48 en `arcData` (`innerRadius 0.7`) et non 40×40 / trait 4px / extrémités arrondies, 12 variantes et non 11.

## 2026-10-05 (2) — Nouveau pattern Filter bar

### Patterns
- **Filter bar** (nouveau) : `Search` + `Select`(s) + « Réinitialiser » + action principale, puis ligne de `Chip` (`Neutral`/`Medium`/`Active`) pour les filtres appliqués et compteur de résultats. Composition de composants existants, assemblage manuel (nombre de filtres arbitraire). Application immédiate par défaut. `FilterBar` retiré des patterns candidats.

### Corrections
- **Chip** : `Label`, `Show-icon-leading`, `Show-icon-trailing` n'étaient pas branchés sur les variantes `Hover`/`Active`/`Disabled` (18 variantes) — corrigé.

## 2026-10-05 — Audit : aucun texte sans Text Style

### Règle
- Tout nœud texte du fichier Figma porte un Text Style (aucune police/taille en dur). Audit sur toutes les pages (hors instances) : 19 textes corrigés.

### Corrections
- **Pagination** : `Label` des `Page-item`, `Ellipsis` et texte « Page {n} sur {N} » en `Misc/Label` (construits à la main au départ).
- **Toast** : bouton « Annuler » (4 variantes `Status`) en `Misc/Label`.
- **Avatar** : initiales en `Body/XS` / `Body/SM` / `Body/LG` (Regular) au lieu de Semi Bold 9,6/12,8/16 px sans style.
- **Guidelines** (pages `Button`, `Numeric inputs`, `Navigation`) : 12 paragraphes à mise en forme mixte — lead-in en `Misc/Label`, suite en `Body/MD`. Les paragraphes de la page `Button` passent de 16 px à 14 px (alignés sur les autres pages).

## 2026-10-04 — Nouveau composant Pagination

### Composants
- **Pagination** (nouveau) : `Page-item` (brique atomique, `State=Default/Hover/Current`, 3 variantes, 32×32) + `Prev`/`Next` (instances de `Button`, `Type=Ghost, Icon-only=true` — deuxième usage réel du gabarit 32×32 établi sur `Search-button`). Pas de composant paramétrique unique — assemblage manuel comme `Table` (nombre de pages arbitraire). Deux structures : `Numbered` (fenêtrage avec `Ellipsis`, texte non componentisé) et `Simple` (« Page {n} sur {N} », espace contraint ou total inconnu). Icônes `CaretLeft`/`CaretRight` (pas de famille `Chevron` dans la fondation).
- **Button** : note mise à jour sur `Icon-only` — `Pagination` en devient le deuxième usage réel (après `Search-button`).
- **decisions.yaml** : ajout de `Pagination` au vocabulaire de `component_selection`.

## 2026-09-30 — Chip/Command-item/Theme switcher : états manquants + Cell, Table

### Composants
- **Chip** : ajout de la propriété `State` (`Default`/`Hover`/`Active`/`Disabled`) — manquait alors que Chip est défini comme interactif. `Active` remplit le Chip (bordure retirée) plutôt que de l'assombrir. `Type` restreint à `Neutral`/`Brand` uniquement (les 4 statuts Feedback retirés — un filtre/sélection actif n'a pas besoin de sémantique de statut). Neutral `Active` corrigé deux fois (`Action/neutral` → `Action/neutral-active` → `Background/inverse`, sur retour direct : pas assez prononcé). 24 variantes (`Type` × `Size` × `State`).
- **Command-item** : ajout de `State=Disabled` — une commande indisponible dans le contexte courant (permission manquante) n'avait aucun traitement visuel prévu.
- **Theme switcher** : ajout de `State` (`Default`/`Hover`/`Disabled`), 12 variantes (2 Mode × 2 Motion × 3 State). Règle de corrélation avec `Motion` posée explicitement : Hover et Disabled ne touchent jamais la Tension-layer/l'Indicator/le filtre `asma-tension`, dans aucune combinaison Mode/Motion.
- **Cell** (nouveau) : brique de contenu d'une cellule de data table — `Content` (`Text`/`Avatar-text`/`Tag`/`Actions`/`Slot`) × `Align` (`Left`/`Right`), 10 variantes. Pas d'état propre : les états sont portés par `Row` dans `Table`.
- **Table** (nouveau) : `Header-cell` (tri `None`/`Asc`/`Desc`, 12 variantes) + `Row` (sélection, `State`×`Selectable`, 8 variantes), construits sur `Cell`. Pas de composant paramétrique unique — assemblage manuel comme `Command`.

## 2026-09-27 (4) — Nettoyage de formulations

### Composants
- **Segmented control** : retiré « Composant unique (pas de variantes) », devenu contradictoire depuis l'ajout de la propriété `Motion` — remplacé par un renvoi explicite à `Motion=Static/Tension`.
- **Theme switcher** : anatomie de la variante `Motion=Tension` clarifiée — les cellules `Cell-active`/`Cell-inactive` y sont renommées `Cell-sun`/`Cell-moon` (positions fixes), c'est l'`Indicator` qui porte l'état actif.
- **Button** : ligne "Guidelines Figma" encore à « 5 Types » après le retrait de `Link` — corrigée en 4 Types.

## 2026-09-27 (3) — Fondation Motion

### Tokens (Primitive)
- **Ajoutés** `Motion/Duration/sm` (240), `Motion/Duration/md` (440) — en ms.
- **Ajoutés** `Motion/Easing/spring`, `Motion/Easing/standard`, `Motion/Easing/accelerate` (courbes cubic-bezier, STRING).
- **Ajoutés** `Motion/Tension/blur` (4), `Motion/Tension/contrast` (18), `Motion/Tension/offset` (−7) — paramètres du filtre SVG de tension de surface.
- `scripts/build_css.py` : génère `--motion-duration-scale-*` (ms), `--motion-easing-scale-*` (courbe brute), `--motion-tension-scale-*`. `dist/tokens.css` régénéré.

### Guidelines
- `foundations.yaml` : Motion ajouté à l'architecture (Primitive uniquement), section `motion` (valeurs, technique, contraintes géométriques, **règles d'usage**).
- `decisions.yaml` : un traitement de mouvement est une variante (`Motion=Static|Tension`), jamais un nouveau composant ; SegmentedControl et ThemeSwitcher autorisés.
- `DESIGN.md`, `README.md` : section Motion, convention de nommage CSS.

### Composants
- **SegmentedControl** : variante `Motion=Tension` documentée (anatomie, comportement, règle d'usage, accessibilité, implémentation de référence).
- **Theme switcher** : variante `Motion=Tension` documentée (4 variantes : 2 Mode × 2 Motion).

### À répercuter dans Figma
- Variables Primitive `Motion/*` (FLOAT/STRING, scopes vides) ; propriété `Motion` sur Segmented-control et Theme-switcher (le filtre n'a pas d'équivalent Figma : la variante Tension y est documentaire / prototype Smart Animate).

## 2026-09-27 (2)

Alignement repo ↔ Figma après répercussion de la MAJ précédente dans Figma.

### Composants
- **Button** : Type `Link` retiré de la spec, de `button.css` (`.btn--link`) et de `button.html` — remplacé par le composant `Link`. 20 variantes (4 Type × 5 State). Disabled : icônes en `Icon/disabled` pour tous les Types.
- **Dialog, Card** : padding `Spacing/component-md` (valeur réellement utilisée dans Figma) au lieu de `Spacing/component-lg`.
- **Theme switcher** : radius du Track = `Radius/card` (lié dans Figma).

### Figma (fait)
- Variable `Icon/on-brand` créée (Semantic, alias Neutral/0, scope SHAPE_FILL).
- Button : icônes Primary → `Icon/on-brand` ; Primary Disabled texte → `Text/disabled` (était `Text/on-brand`, quasi invisible) ; icônes Disabled de tous les Types → `Icon/disabled`.
- `Radius/card` lié sur Card (3 variantes), Command, Drawer (coins côté contenu), Theme switcher.

### Réglé
- **Popover** : `Radius/md` (16px) lié dans Figma, conforme à la spec.

## 2026-09-27

Corrections issues du prototype ASMA OS (écran Entreprises) et d'un audit de cohérence repo / Figma.

### Tokens
- **Ajouté** `Icon/on-brand` (Semantic, Neutral/0 en Light et Dark) — icônes posées sur un fond de marque.
- **Modifié** `Feedback/{Info,Success,Warning,Danger}/background` : grade 50/950 → **100/900** (correction annoncée dans la spec Tag et déjà appliquée dans Figma, jamais reportée dans `tokens/semantic.json`).
- **Corrigé** `scripts/build_css.py` : les familles de police génèrent désormais `--font-family-scale-*` (nom documenté, attendu par `button.css`) au lieu de `--family-scale-*`. `dist/tokens.css` régénéré.

### Guidelines
- `foundations.yaml` : `Icon/on-brand` ajouté aux rôles ; note sur les fonds Feedback ; règle d'usage d'Alternate (JetBrains Mono) étendue au style `Misc/Caption`.
- `DESIGN.md` : valeurs réalignées sur les tokens (`border-default` #64748b, `border-strong` #475569, `text-secondary` #334155, échelle typo, `label` 14/20 Semi Bold, `caption` JetBrains Mono 12/16) ; règle `on-brand` documentée.
- `README.md` : paragraphe obsolète « Restent : … » retiré ; liens vers les nouvelles specs.

### Composants
- **Button** : Primary `Text/inverse` / `Icon/inverse` → `Text/on-brand` / `Icon/on-brand` (texte quasi noir en Dark, contraste ≈ 3,4:1) ; libellé en Semi Bold (600) comme `Misc/Label`. `button.css` mis à jour.
- **Dialog, Drawer, Card, Command, Popover** : références à des tokens inexistants (`Radius/lg`, `Spacing/lg`/`Spacing/md` Responsive, `Shadow/*`, `Overlay/scrim`) remappées sur `Radius/card`, `Spacing/component-lg`, `Spacing/component-md` ; ombre et voile documentés sans token.
- **Theme switcher** : nouvelle spec `components/theme-switcher/`, rédigée depuis Figma.

### Patterns
- **Sidebar** : nouvelle spec `patterns/navigation/sidebar-pattern-spec.md`, rédigée depuis Figma.

### À répercuter dans Figma
- Variable `Icon/on-brand` à créer ; Button/Primary à relier à `Text/on-brand` / `Icon/on-brand` et passer en Semi Bold.
- Dialog, Drawer, Card, Command, Popover : vérifier que les liaisons de variables correspondent au remapping.
- Theme switcher : lier le radius du Track à `Radius/card`.
